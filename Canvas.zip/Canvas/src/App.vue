<script setup lang="ts">
import MindMap from './mindmap/MindMap.vue'
</script>

<template>
  <div class="w-full h-full flex flex-col">
    <header class="px-4 py-2.5 border-b border-slate-200 bg-white flex items-baseline gap-4 flex-wrap shrink-0">
      <h1 class="text-base font-semibold text-slate-900">思维导图 · Vue3 + AntV X6</h1>
      <p class="text-xs text-slate-500">
        Case → 怀疑方向 → 执行任务。节点为 Vue 组件(含表单/图标)，canvas 风格交互：拖拽改父、缩放平移、撤销、小地图。
      </p>
    </header>
    <div class="flex-1 min-h-0">
      <MindMap />
    </div>
  </div>
</template>
