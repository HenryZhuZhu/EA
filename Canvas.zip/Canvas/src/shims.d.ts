declare module '*.vue' {
  import type { DefineComponent } from 'vue'
  const component: DefineComponent<{}, {}, any>
  export default component
}

declare module '@antv/hierarchy' {
  interface HierarchyResult {
    id: string
    x: number
    y: number
    data: any
    children?: HierarchyResult[]
  }
  interface CompactBoxOptions {
    direction?: 'LR' | 'RL' | 'TB' | 'BT' | 'H' | 'V'
    getId?: (d: any) => string
    getWidth?: (d: any) => number
    getHeight?: (d: any) => number
    getHGap?: (d: any) => number
    getVGap?: (d: any) => number
    getSide?: (d: any) => 'left' | 'right'
  }
  const Hierarchy: {
    compactBox(data: any, options: CompactBoxOptions): HierarchyResult
    dendrogram(data: any, options: CompactBoxOptions): HierarchyResult
    mindmap(data: any, options: CompactBoxOptions): HierarchyResult
    indented(data: any, options: CompactBoxOptions): HierarchyResult
  }
  export default Hierarchy
}
