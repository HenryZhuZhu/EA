import { onMounted, onBeforeUnmount, ref, shallowRef, reactive } from 'vue'
import { Graph, type Node } from '@antv/x6'
import { Selection } from '@antv/x6-plugin-selection'
import { History } from '@antv/x6-plugin-history'
import { Snapline } from '@antv/x6-plugin-snapline'
import { Keyboard } from '@antv/x6-plugin-keyboard'
import { MiniMap } from '@antv/x6-plugin-minimap'

import { computeLayout, INDENT } from './useLayout'
import { createSampleTree } from './data'
import { SIZE, shapeOf } from './theme'
import type { NodeKind, NodeData, TreeNode } from './types'

// ───────── 节点组件 ↔ 画布逻辑 的共享响应式状态 ─────────

/** 拖拽时的 UI 共享状态：节点组件据此渲染“候选父节点”高亮环 */
export const dragUI = reactive<{ candidateId: string | null; draggingId: string | null }>({
  candidateId: null,
  draggingId: null,
})

/** 各节点的派生元信息（供收起/展开按钮使用）：子节点数、子孙任务总数、是否收起 */
export const nodeMeta = reactive<Record<string, { childCount: number; taskCount: number; collapsed: boolean }>>({})

/** 节点组件 → 画布 的动作回调。useFlow 挂载时注册实现，节点内部只管调用 */
export interface MindMapActions {
  relayout: () => void
  /** 在 parentId 下新增一个子节点，返回新节点 id */
  addChild: (parentId: string, kind: Exclude<NodeKind, 'case'>) => string
  /** 在 parentId 下新增「思路 + 任务」节点组（思路含一个任务），返回新思路 id */
  addGroup: (parentId: string) => string
  /** 删除节点及其整棵子树 */
  remove: (id: string) => void
  /** 局部更新某节点数据（表单回写） */
  update: (id: string, patch: Partial<NodeData>) => void
  /** 节点内容高度变化（表单展开/折叠）时上报，触发 resize + 重新布局 */
  reportHeight: (id: string, height: number) => void
  /** 标记整条线（从根到该节点的路径） */
  flagLine: (id: string) => void
  /** 打开 Workspace 笔记（结论外链占位） */
  openWorkspace: (id: string) => void
  /** 收起 / 展开某节点的子树 */
  toggleCollapse: (id: string) => void
}

export const actions: Partial<MindMapActions> = {}

// ───────── 纯数据：树的增删改查辅助 ─────────

function findNode(root: TreeNode, id: string): TreeNode | null {
  if (root.id === id) return root
  for (const c of root.children ?? []) {
    const r = findNode(c, id)
    if (r) return r
  }
  return null
}

function findParent(root: TreeNode, id: string): TreeNode | null {
  for (const c of root.children ?? []) {
    if (c.id === id) return root
    const r = findParent(c, id)
    if (r) return r
  }
  return null
}

/** 可见节点 id（遇到收起的节点则不再深入其子孙） */
function collectVisibleIds(root: TreeNode): string[] {
  const ids: string[] = []
  ;(function walk(n: TreeNode) {
    ids.push(n.id)
    if (!n.collapsed) (n.children ?? []).forEach(walk)
  })(root)
  return ids
}

/** 某节点其下所有「任务(task)」节点的数量之和（含被收起的子孙） */
function countTasks(node: TreeNode): number {
  let n = 0
  ;(node.children ?? []).forEach((c) => {
    if (c.kind === 'task') n += 1
    n += countTasks(c)
  })
  return n
}

/** 收集某节点的全部后代 id（含自身），用于拖拽改父时的成环校验 */
function collectSubtreeIds(node: TreeNode, acc = new Set<string>()): Set<string> {
  acc.add(node.id)
  for (const c of node.children ?? []) collectSubtreeIds(c, acc)
  return acc
}

let idSeq = 100
function nextId(prefix: string): string {
  idSeq += 1
  return `${prefix}${idSeq}`
}

/** 新建一个空白「思路」节点 */
function makeThought(): TreeNode {
  return { id: nextId('t'), kind: 'thought', data: { tag: '新方向', title: '（待补充）怀疑方向' } }
}

/** 新建一个空白「任务」节点 */
function makeTask(): TreeNode {
  return {
    id: nextId('a'),
    kind: 'task',
    data: { status: '待接受', urgency: '一般', title: '新执行任务', owner: '待指派', due: '', expect: '（待补充）', concl: '' },
  }
}

/**
 * 思维导图的全部业务逻辑：图引擎创建、节点增删改查与图同步、拖拽改父 +
 * 边缘自动平移、节点动作注册、工具栏与生命周期。位置计算委托给 useLayout。
 * 组件只负责模板与样式。
 */
export function useFlow() {
  const containerEl = ref<HTMLElement | null>(null)
  const minimapEl = ref<HTMLElement | null>(null)
  const graph = shallowRef<Graph | null>(null)
  let history: History | null = null

  /** 思维导图的唯一数据源 */
  const tree = ref<TreeNode>(createSampleTree())
  /** 各节点实际高度（表单展开等会覆盖默认值） */
  const heights: Record<string, number> = {}
  /** 被「标记整条线」选中的节点（demo：高亮其根到该节点路径） */
  const flaggedId = ref<string | null>(null)

  // ───────── 图同步：tree 数据 → X6 画布节点/连线 ─────────

  function isOnFlaggedPath(id: string): boolean {
    if (!flaggedId.value) return false
    let cur: TreeNode | null = findNode(tree.value, flaggedId.value)
    while (cur) {
      if (cur.id === id) return true
      cur = findParent(tree.value, cur.id)
    }
    return false
  }

  function buildEdge(parentId: string, childId: string) {
    const g = graph.value!
    const onPath = isOnFlaggedPath(parentId) && isOnFlaggedPath(childId)
    const stroke = onPath ? '#f59e0b' : '#cbd5e1'
    const strokeWidth = onPath ? 2.5 : 2
    // 任务在父节点下方 → 正交连线（缩进槽里走竖直主干，再水平拐入任务左侧）；
    // 思路在父节点右侧 → 平滑曲线（横向分支）
    const isDown = findNode(tree.value, childId)?.kind === 'task'

    const cfg: any = {
      id: `e_${childId}`,
      data: { childId },
      attrs: { line: { stroke, strokeWidth, targetMarker: null } },
      zIndex: 1,
    }
    // 连线起点对齐到父节点的「收起/展开按钮」中心，使按钮成为连线汇聚点
    // （按钮几何：见各节点的 CollapseToggle 定位；20px 圆钮）
    if (isDown) {
      const pw = SIZE[findNode(tree.value, parentId)?.kind ?? 'thought'].width
      // 思路按钮：缩进槽 x = INDENT/2 - pw/2；下方 -bottom-6(24px) 处按钮中心 y = bottom + (24 - 20/2)
      cfg.source = { cell: parentId, anchor: { name: 'bottom', args: { dx: Math.round(INDENT / 2 - pw / 2), dy: 14 } } }
      cfg.target = { cell: childId, anchor: { name: 'left' } }
      cfg.router = { name: 'orth', args: { padding: 6 } }
      cfg.connector = { name: 'rounded', args: { radius: 6 } }
    } else {
      // case/任务按钮：右侧 -right-7(28px) 处按钮中心 x = right + (28 - 20/2)
      cfg.source = { cell: parentId, anchor: { name: 'right', args: { dx: 18 } } }
      cfg.target = { cell: childId, anchor: { name: 'left' } }
      cfg.connector = { name: 'smooth' }
    }
    g.addEdge(cfg)
  }

  /** 增量同步节点：只增删差异部分，不重建全部 */
  function syncNodes() {
    const g = graph.value!
    const want = new Set(collectVisibleIds(tree.value))
    g.getNodes().forEach((n) => {
      if (!want.has(n.id)) n.remove()
    })
    want.forEach((id) => {
      if (!g.getCellById(id)) {
        const tn = findNode(tree.value, id)!
        g.addNode({
          id,
          shape: shapeOf[tn.kind],
          x: 0,
          y: 0,
          width: SIZE[tn.kind].width,
          height: heights[id] ?? SIZE[tn.kind].height,
          data: { ...tn.data },
          zIndex: 10,
        })
      }
    })
  }

  /** 增量同步连线：按 child 唯一定位边，只增/删/改受影响的边，并刷新标记路径配色 */
  function syncEdges() {
    const g = graph.value!
    const desired = new Map<string, string>() // childId -> parentId
    ;(function walk(n: TreeNode) {
      if (n.collapsed) return // 收起的节点不渲染其子连线
      ;(n.children ?? []).forEach((c) => {
        desired.set(c.id, n.id)
        walk(c)
      })
    })(tree.value)

    g.getEdges().forEach((e) => {
      const childId = (e.getData() as any)?.childId as string | undefined
      if (!childId || !desired.has(childId)) e.remove()
    })
    desired.forEach((parentId, childId) => {
      const edge = g.getCellById(`e_${childId}`) as any
      if (!edge) {
        buildEdge(parentId, childId)
        return
      }
      // 改父：源端变了 → 重建以重算锚点与走线方式
      if (edge.getSourceCellId?.() !== parentId) {
        edge.remove()
        buildEdge(parentId, childId)
        return
      }
      const onPath = isOnFlaggedPath(parentId) && isOnFlaggedPath(childId)
      edge.attr('line/stroke', onPath ? '#f59e0b' : '#cbd5e1')
      edge.attr('line/strokeWidth', onPath ? 2.5 : 2)
    })
  }

  /** 重算各节点派生元信息（子节点数 / 子孙任务数 / 收起态），供收起按钮渲染 */
  function updateMeta() {
    const seen = new Set<string>()
    ;(function walk(n: TreeNode) {
      seen.add(n.id)
      nodeMeta[n.id] = { childCount: n.children?.length ?? 0, taskCount: countTasks(n), collapsed: !!n.collapsed }
      ;(n.children ?? []).forEach(walk)
    })(tree.value)
    for (const k of Object.keys(nodeMeta)) if (!seen.has(k)) delete nodeMeta[k]
  }

  /** 结构变更后调用：同步节点 + 连线，再重新布局 */
  function syncGraph() {
    const g = graph.value
    if (!g) return
    updateMeta()
    syncNodes()
    syncEdges()
    applyLayout()
  }

  /** 用 useLayout 算坐标并应用到画布（位置/尺寸变化时调用，不增删节点） */
  function applyLayout() {
    const g = graph.value
    if (!g) return
    const positions = computeLayout(tree.value, heights)
    const kindById = new Map<string, NodeKind>()
    ;(function walk(n: TreeNode) {
      kindById.set(n.id, n.kind)
      ;(n.children ?? []).forEach(walk)
    })(tree.value)
    positions.forEach((p) => {
      const n = g.getCellById(p.id) as Node | undefined
      if (!n) return
      const kind = kindById.get(p.id)
      if (kind) n.resize(SIZE[kind].width, heights[p.id] ?? SIZE[kind].height)
      n.setPosition(p.x, p.y)
    })
  }

  // 把同一帧内的多次高度上报合并为一次重新布局，避免启动时 O(N²) 反复布局
  let relayoutRaf = 0
  function scheduleRelayout() {
    if (relayoutRaf) return
    relayoutRaf = requestAnimationFrame(() => {
      relayoutRaf = 0
      applyLayout()
    })
  }

  // ───────── 拖拽改父：拖动时按区域自动识别落点父节点 + 边缘自动平移 ─────────

  const FOLLOW_LIMIT = 60 // 子树规模超过此值时，拖拽中只动被拖节点（大图保持流畅），落子后统一归位

  let subtreeIds = new Set<string>()
  let descendantIds: string[] = []
  let dragNodeId: string | null = null
  let lastNodePos = { x: 0, y: 0 }
  let followSubtree = false
  let grabbed = false
  let grabOffset = { x: 0, y: 0 } // 被拖节点位置 - 光标在图坐标的位置（抓取时的相对偏移）

  function moveCellsBy(ids: Iterable<string>, dx: number, dy: number) {
    if (!dx && !dy) return
    const g = graph.value!
    for (const id of ids) {
      const n = g.getCellById(id) as Node | undefined
      if (!n) continue
      const p = n.position()
      n.setPosition(p.x + dx, p.y + dy)
    }
  }

  // ───────── 改父业务规则 ─────────

  function kindOf(id: string): NodeKind | undefined {
    return findNode(tree.value, id)?.kind
  }

  /** 规则1：思路下有且仅有一个任务时，该任务被锁定，不允许单独拖动改父；根 case 也不可改父 */
  function isMovable(id: string): boolean {
    const node = findNode(tree.value, id)
    if (!node || node.id === tree.value.id) return false
    if (node.kind === 'task') {
      const parent = findParent(tree.value, id)
      if (parent?.kind === 'thought') {
        const taskCount = (parent.children ?? []).filter((c) => c.kind === 'task').length
        if (taskCount <= 1) return false
      }
    }
    return true
  }

  /**
   * 规则2/3/4：能否把 draggedId 挂到 targetId 之下（建立 target→dragged 连线）
   * - 任务(task) 只能挂到 思路(thought) 下（任务↔任务不允许）
   * - 思路(thought) 只能挂到 case 或 任务(task) 下（思路↔思路不允许）
   */
  function canDropUnder(draggedId: string, targetId: string): boolean {
    const dk = kindOf(draggedId)
    const tk = kindOf(targetId)
    if (!dk || !tk) return false
    if (dk === 'task') return tk === 'thought'
    if (dk === 'thought') return tk === 'case' || tk === 'task'
    return false
  }

  function onMoveStart({ node }: { node: Node }) {
    const moving = findNode(tree.value, node.id)
    if (!moving) return
    subtreeIds = collectSubtreeIds(moving)
    descendantIds = [...subtreeIds].filter((id) => id !== node.id)
    followSubtree = descendantIds.length <= FOLLOW_LIMIT
    dragNodeId = node.id
    lastNodePos = node.position()
    grabbed = false
  }

  function onMoving({ e, node }: { e: any; node: Node }) {
    if (dragUI.draggingId !== node.id) {
      if (!subtreeIds.has(node.id)) return
      dragUI.draggingId = node.id
      history?.disable()
    }
    const g = graph.value!
    if (!grabbed) {
      const cl = g.clientToLocal(e.clientX, e.clientY)
      const p = node.position()
      grabOffset = { x: p.x - cl.x, y: p.y - cl.y }
      grabbed = true
    }
    const cur = node.position()
    if (followSubtree) moveCellsBy(descendantIds, cur.x - lastNodePos.x, cur.y - lastNodePos.y)
    lastNodePos = { x: cur.x, y: cur.y }

    lastClient = { x: e.clientX, y: e.clientY }
    updateAutopan()
    detectCandidate(node)
  }

  function detectCandidate(node: Node) {
    const g = graph.value!
    // 规则1：锁定的节点不产生任何落点（拖动也会被 nodeMovable 拦截，这里做兜底）
    if (!isMovable(node.id)) {
      dragUI.candidateId = null
      return
    }
    const curParent = findParent(tree.value, node.id)
    const under = (g.getNodesUnderNode(node, { by: 'bbox' }) as Node[]) || []
    const center = node.getBBox().getCenter()
    let best: Node | null = null
    let bestDist = Infinity
    under.forEach((n) => {
      if (subtreeIds.has(n.id)) return // 排除自身及后代，杜绝成环
      if (curParent && n.id === curParent.id) return // 当前父节点 = 无变化
      if (!canDropUnder(node.id, n.id)) return // 规则2/3/4：类型校验，仅合法目标高亮
      const c = n.getBBox().getCenter()
      const d = (c.x - center.x) ** 2 + (c.y - center.y) ** 2
      if (d < bestDist) {
        bestDist = d
        best = n
      }
    })
    dragUI.candidateId = best ? (best as Node).id : null
  }

  // 边缘自动平移：拖到视口边缘时画布持续朝该方向滚动，被拖子树固定在光标下
  let lastClient = { x: 0, y: 0 }
  let panVx = 0
  let panVy = 0
  let panRaf = 0

  function updateAutopan() {
    const g = graph.value
    if (!g) return
    const rect = g.container.getBoundingClientRect()
    const m = 64 // 触发自动平移的边缘厚度
    const max = 22 // 每帧最大平移像素
    const { x, y } = lastClient
    let vx = 0
    let vy = 0
    if (x < rect.left + m) vx = max * Math.min(1, (rect.left + m - x) / m)
    else if (x > rect.right - m) vx = -max * Math.min(1, (x - (rect.right - m)) / m)
    if (y < rect.top + m) vy = max * Math.min(1, (rect.top + m - y) / m)
    else if (y > rect.bottom - m) vy = -max * Math.min(1, (y - (rect.bottom - m)) / m)
    panVx = vx
    panVy = vy
    if ((vx || vy) && !panRaf) panRaf = requestAnimationFrame(autopanTick)
  }

  function autopanTick() {
    panRaf = 0
    if (!dragUI.draggingId || !dragNodeId || (!panVx && !panVy)) return
    const g = graph.value!
    const n = g.getCellById(dragNodeId) as Node | undefined
    if (!n) return
    g.translateBy(panVx, panVy)
    const cl = g.clientToLocal(lastClient.x, lastClient.y)
    const target = { x: cl.x + grabOffset.x, y: cl.y + grabOffset.y }
    const cur = n.position()
    moveCellsBy(followSubtree ? subtreeIds : [dragNodeId], target.x - cur.x, target.y - cur.y)
    lastNodePos = n.position()
    detectCandidate(n)
    panRaf = requestAnimationFrame(autopanTick)
  }

  function stopAutopan() {
    if (panRaf) cancelAnimationFrame(panRaf)
    panRaf = 0
    panVx = 0
    panVy = 0
  }

  function onMoveEnd({ node }: { node: Node }) {
    stopAutopan()
    const cand = dragUI.candidateId
    dragUI.draggingId = null
    dragUI.candidateId = null
    dragNodeId = null
    grabbed = false
    history?.enable() // 恢复历史后再做结构变更，使“改父”可撤销
    let reparented = false
    if (cand && node.id !== tree.value.id) {
      reparented = reparent(node.id, cand)
    }
    if (reparented) syncGraph()
    else applyLayout() // 未命中合法落点 → 子树归位
  }

  function reparent(childId: string, newParentId: string): boolean {
    const child = findNode(tree.value, childId)
    const newParent = findNode(tree.value, newParentId)
    if (!child || !newParent) return false
    if (!isMovable(childId)) return false // 规则1
    if (!canDropUnder(childId, newParentId)) return false // 规则2/3/4
    if (collectSubtreeIds(child).has(newParentId)) return false // 不能拖到自己的子孙下
    const oldParent = findParent(tree.value, childId)
    if (!oldParent || oldParent.id === newParentId) return false
    oldParent.children = (oldParent.children ?? []).filter((c) => c.id !== childId)
    ;(newParent.children ??= []).push(child)
    return true
  }

  // ───────── 节点增删改查动作（暴露给节点组件） ─────────

  function registerActions() {
    actions.relayout = () => applyLayout()
    actions.addChild = (parentId: string, kind: Exclude<NodeKind, 'case'>) => {
      const parent = findNode(tree.value, parentId)
      if (!parent) return ''
      const node = kind === 'thought' ? makeThought() : makeTask()
      ;(parent.children ??= []).push(node)
      syncGraph()
      return node.id
    }
    actions.addGroup = (parentId: string) => {
      const parent = findNode(tree.value, parentId)
      if (!parent) return ''
      // 一个「思路」组：思路节点 + 其下一个任务节点
      const thought = makeThought()
      ;(thought.children ??= []).push(makeTask())
      ;(parent.children ??= []).push(thought)
      syncGraph()
      return thought.id
    }
    actions.remove = (id: string) => {
      if (id === tree.value.id) return
      const parent = findParent(tree.value, id)
      if (!parent) return
      parent.children = (parent.children ?? []).filter((c) => c.id !== id)
      delete heights[id]
      syncGraph()
    }
    actions.update = (id: string, patch) => {
      const tn = findNode(tree.value, id)
      if (!tn) return
      Object.assign(tn.data, patch)
      const gn = graph.value!.getCellById(id) as Node | undefined
      gn?.setData(patch)
    }
    actions.reportHeight = (id: string, h: number) => {
      const prev = heights[id] ?? SIZE[findNode(tree.value, id)?.kind ?? 'task'].height
      if (Math.abs(prev - h) < 2) return
      heights[id] = h
      if (dragUI.draggingId) return // 拖拽中不重排，避免把被拖节点拉回布局位
      scheduleRelayout() // 合并到下一帧统一布局
    }
    actions.flagLine = (id: string) => {
      flaggedId.value = flaggedId.value === id ? null : id
      syncEdges() // 仅刷新连线配色，无需结构重建
    }
    actions.openWorkspace = (id: string) => {
      // 占位：实际项目里跳转 Workspace 笔记
      console.info('[MindMap] open workspace note for node:', id)
    }
    actions.toggleCollapse = (id: string) => {
      const node = findNode(tree.value, id)
      if (!node || !(node.children && node.children.length)) return
      const g = graph.value
      // 记录被切换节点在屏幕上的位置（收起前）
      const cell = g?.getCellById(id) as Node | undefined
      const before = cell ? g!.localToClient(cell.position().x, cell.position().y) : null
      node.collapsed = !node.collapsed
      syncGraph()
      // 收起/展开后保持该节点屏幕位置不变（避免根节点收起后被重排到顶部、跑出视口而“消失”）
      if (g && before) {
        const cell2 = g.getCellById(id) as Node | undefined
        if (cell2) {
          const after = g.localToClient(cell2.position().x, cell2.position().y)
          g.translateBy(before.x - after.x, before.y - after.y)
        }
      }
    }
  }

  // ───────── 工具栏 ─────────

  function undo() {
    graph.value?.canUndo() && graph.value.undo()
  }
  function redo() {
    graph.value?.canRedo() && graph.value.redo()
  }
  function zoomIn() {
    graph.value?.zoom(0.15)
  }
  function zoomOut() {
    graph.value?.zoom(-0.15)
  }
  function fit() {
    const g = graph.value
    if (!g) return
    // 容器尚未拿到真实高度时（如刚挂载的一两帧内）跳过，避免 zoomToFit 算出极小缩放
    const h = g.container?.clientHeight ?? 0
    const w = g.container?.clientWidth ?? 0
    if (h < 80 || w < 80) return
    g.zoomToFit({ padding: 40, maxScale: 1, minScale: 0.2 })
  }

  /** 启动时多次尝试 fit，确保在 flex 容器尺寸与节点高度都稳定后命中一次正确缩放 */
  function startupFit() {
    requestAnimationFrame(() => requestAnimationFrame(() => fit()))
    setTimeout(fit, 120)
    setTimeout(fit, 300)
  }

  function loadTree(factory: () => TreeNode) {
    flaggedId.value = null
    for (const k of Object.keys(heights)) delete heights[k]
    tree.value = factory()
    syncGraph()
    startupFit()
  }

  function reset() {
    loadTree(createSampleTree)
  }

  // ───────── 生命周期 ─────────

  onMounted(() => {
    const g = new Graph({
      container: containerEl.value!,
      autoResize: true,
      async: true, // 异步调度渲染：大图分帧批量出图，主线程更跟手
      background: { color: '#f8fafc' },
      grid: { size: 20, visible: true, type: 'dot', args: { color: '#e2e8f0', thickness: 1 } as any },
      panning: { enabled: true, eventTypes: ['leftMouseDown'] },
      mousewheel: { enabled: true, factor: 1.1, minScale: 0.2, maxScale: 2.5 },
      // 规则1：思路下唯一的任务节点锁定、不可拖动；根 case 也不可拖动改父
      interacting: { nodeMovable: (view: any) => isMovable(view?.cell?.id), edgeMovable: false },
      connecting: { allowBlank: false, allowLoop: false, allowNode: false },
    })
    graph.value = g

    history = new History({ enabled: true })
    g.use(history)
    g.use(new Selection({ enabled: true, multiple: true, rubberband: true, modifiers: 'shift', showNodeSelectionBox: true }))
    g.use(new Snapline({ enabled: true }))
    g.use(new Keyboard({ enabled: true }))
    g.use(new MiniMap({ container: minimapEl.value!, width: 200, height: 140, padding: 8 }))

    // 快捷键
    g.bindKey(['meta+z', 'ctrl+z'], () => { undo(); return false })
    g.bindKey(['meta+shift+z', 'ctrl+shift+z', 'ctrl+y'], () => { redo(); return false })
    g.bindKey(['backspace', 'delete'], () => {
      g.getSelectedCells().forEach((c) => c.isNode() && actions.remove?.(c.id))
      return false
    })

    // hover 置顶，保证展开浮层不被相邻节点遮挡
    g.on('node:mouseenter', ({ node }) => node.setZIndex(1000, { silent: true } as any))

    // 拖拽改父：mousedown 记录起点，moving 跟随+识别落点，moved 落子
    g.on('node:mousedown', onMoveStart as any)
    g.on('node:moving', onMoving as any)
    g.on('node:moved', onMoveEnd as any)

    registerActions()
    loadTree(createSampleTree)
  })

  onBeforeUnmount(() => {
    stopAutopan()
    if (relayoutRaf) cancelAnimationFrame(relayoutRaf)
    graph.value?.dispose()
  })

  return {
    containerEl,
    minimapEl,
    graph,
    tree,
    undo,
    redo,
    zoomIn,
    zoomOut,
    fit,
    reset,
  }
}
