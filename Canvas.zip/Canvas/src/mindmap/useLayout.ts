import { SIZE } from './theme'
import type { TreeNode } from './types'

/**
 * 纯布局 / 位置计算模块：只负责「给定一棵 tree 算出每个节点的坐标」，
 * 不触碰 X6、不做任何图的增删改查（那些在 useFlow 中）。
 */

export interface Positioned {
  id: string
  x: number
  y: number
}

const PADDING = 40
const COL_GAP = 64 // 「思路」向右分支与父节点的水平间距
const ROW_GAP = 16 // 垂直堆叠间距
const DOWN_HEAD_GAP = 32 // 思路与其首个任务之间的额外空隙，留给收起/展开按钮
export const INDENT = 40 // 「任务」相对所属思路的缩进（左侧留出连线主干的水平槽）

/**
 * 分组布局：
 * - 「任务(task)」节点堆叠在其所属「思路(thought)」节点的【下方】，缩进对齐，形成一组；
 * - 「思路(thought)」节点仍向【右】分支（多个怀疑方向并列展开），纵向依次排布；
 * - 无下方任务、仅有右向子节点的节点（如 Case）相对其子节点组纵向居中（X 轴对称）；
 * - 每个节点返回整组的右/下边界，保证不同支线之间不重叠。
 *
 * @param heights 各节点实际高度（表单/悬停展开等会覆盖默认值）
 */
export function computeLayout(root: TreeNode, heights: Record<string, number> = {}): Positioned[] {
  const out: Positioned[] = []
  const H = (n: TreeNode) => heights[n.id] ?? SIZE[n.kind].height
  const W = (n: TreeNode) => SIZE[n.kind].width

  // 把 node 的整组放在以 (x, y) 为左上的区域，递归排布子节点，返回整组的右/下边界
  function place(n: TreeNode, x: number, y: number): { right: number; bottom: number } {
    const cw = W(n)
    const ch = H(n)
    let right = x + cw
    let bottom = y + ch

    const kids = n.collapsed ? [] : n.children ?? [] // 收起的节点视作叶子
    const downKids = kids.filter((c) => c.kind === 'task') // 任务 → 下方
    const rightKids = kids.filter((c) => c.kind !== 'task') // 思路 → 右侧

    // 下方任务堆叠（缩进）；首个任务额外留出收起/展开按钮的竖向空隙
    const ax = x + INDENT
    let ay = y + ch + (downKids.length ? DOWN_HEAD_GAP : ROW_GAP)
    for (const c of downKids) {
      const b = place(c, ax, ay)
      ay = b.bottom + ROW_GAP
      right = Math.max(right, b.right)
      bottom = Math.max(bottom, b.bottom)
    }

    // 右向思路分支（水平避开下方任务列）
    const tx = Math.max(x + cw, right) + COL_GAP
    let ty = y
    for (const c of rightKids) {
      const b = place(c, tx, ty)
      ty = b.bottom + ROW_GAP
      right = Math.max(right, b.right)
      bottom = Math.max(bottom, b.bottom)
    }
    const rightBottom = ty - ROW_GAP // 最后一个右向子节点的底部

    // 节点卡片纵向位置：
    // - 有下方任务时，节点作为「组头」置于顶部（y），任务依次列于其下；
    // - 无下方任务、仅有右向子节点时（如 Case），节点相对子节点组 X 轴居中。
    let nodeY = y
    if (downKids.length === 0 && rightKids.length > 0) {
      nodeY = Math.max(y, (y + rightBottom) / 2 - ch / 2)
      bottom = Math.max(bottom, nodeY + ch)
    }
    out.push({ id: n.id, x, y: nodeY })

    return { right, bottom }
  }

  place(root, PADDING, PADDING)
  return out
}
