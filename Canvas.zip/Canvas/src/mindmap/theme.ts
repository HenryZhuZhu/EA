import type { Status, Urgency, Level, Validity, NodeKind } from './types'

/** 节点类型 → 注册的 X6 shape 名 */
export const shapeOf: Record<NodeKind, string> = {
  case: 'case-node',
  thought: 'thought-node',
  task: 'task-node',
}

/** 状态配色（与原型一致） */
export const STATUS: Record<Status, { badge: string; dot: string; bar: string; solid: string; tint: string; tintBd: string; text: string; border: string; icon: string }> = {
  待接受: { badge: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-400', bar: 'bg-amber-400', solid: 'bg-amber-500', tint: 'bg-amber-50', tintBd: 'border-amber-200', text: 'text-amber-700', border: 'border-amber-300', icon: 'Hourglass' },
  进行中: { badge: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-500', bar: 'bg-blue-500', solid: 'bg-blue-600', tint: 'bg-blue-50', tintBd: 'border-blue-200', text: 'text-blue-700', border: 'border-blue-300', icon: 'Clock' },
  已拒绝: { badge: 'bg-red-50 text-red-700 border-red-200', dot: 'bg-red-500', bar: 'bg-red-500', solid: 'bg-red-600', tint: 'bg-red-50', tintBd: 'border-red-200', text: 'text-red-700', border: 'border-red-300', icon: 'Ban' },
  已完成: { badge: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500', bar: 'bg-emerald-500', solid: 'bg-emerald-600', tint: 'bg-emerald-50', tintBd: 'border-emerald-200', text: 'text-emerald-700', border: 'border-emerald-300', icon: 'Check' },
  已中止: { badge: 'bg-slate-100 text-slate-600 border-slate-200', dot: 'bg-slate-400', bar: 'bg-slate-400', solid: 'bg-slate-500', tint: 'bg-slate-50', tintBd: 'border-slate-200', text: 'text-slate-500', border: 'border-slate-300', icon: 'CircleSlash' },
}

/** 紧急度配色 */
export const URG: Record<Urgency, { stripe: string; dot: string; label: string }> = {
  非常紧急: { stripe: 'border-l-red-400', dot: 'bg-red-400', label: '非常紧急' },
  紧急: { stripe: 'border-l-orange-400', dot: 'bg-orange-400', label: '紧急' },
  一般: { stripe: 'border-l-sky-400', dot: 'bg-sky-400', label: '一般' },
  不紧急: { stripe: 'border-l-slate-300', dot: 'bg-slate-300', label: '不紧急' },
}

/** Case 级别配色 */
export const LEVEL: Record<Level, string> = {
  L1: 'bg-red-50 text-red-600 border-red-200',
  L2: 'bg-orange-50 text-orange-600 border-orange-200',
  L3: 'bg-amber-50 text-amber-600 border-amber-200',
  L4: 'bg-blue-50 text-blue-600 border-blue-200',
  L5: 'bg-slate-50 text-slate-600 border-slate-200',
}

/** 有效性结论配色 */
export const VALIDITY: Record<Exclude<Validity, ''>, string> = {
  有效: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  部分有效: 'bg-amber-50 text-amber-700 border-amber-200',
  无效: 'bg-rose-50 text-rose-700 border-rose-200',
}

/** 各类节点的卡片尺寸（用于布局；高度为折叠态基准值，可被实际测量覆盖） */
export const SIZE: Record<string, { width: number; height: number }> = {
  case: { width: 230, height: 96 },
  thought: { width: 250, height: 92 },
  task: { width: 248, height: 150 },
}

export const STATUS_OPTIONS: Status[] = ['待接受', '进行中', '已拒绝', '已完成', '已中止']
export const URGENCY_OPTIONS: Urgency[] = ['非常紧急', '紧急', '一般', '不紧急']
export const VALIDITY_OPTIONS: Validity[] = ['', '有效', '部分有效', '无效']
