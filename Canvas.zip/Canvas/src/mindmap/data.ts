import type { TreeNode } from './types'

/** 示例思维导图：1 Case + 4 怀疑方向 + 1 子思路 + 10 执行任务（与原型一致） */
export function createSampleTree(): TreeNode {
  return {
    id: 'case',
    kind: 'case',
    data: { level: 'L2', code: 'EA-260511000001', title: 'CP1 良率掉点集中在 Wafer 边缘', site: 'SiteA', owner: '张伟' },
    children: [
      {
        id: 't1',
        kind: 'thought',
        data: { tag: '测试程式', title: '怀疑高频 pattern 下 guardband 偏紧，导致边缘 die ICC2 误判' },
        children: [
          { id: 'a1', kind: 'task', data: { status: '进行中', urgency: '一般', title: 'ICC2 分布分析与 Pattern 定位', owner: '张伟', due: '04-22', expect: '验证边缘 die 在高频 pattern 下 ICC2 是否超出 guardband。', concl: '初步定位为边缘 die ICC2 偏高，疑似 guardband 设置。', validity: '部分有效' } },
          { id: 'a2', kind: 'task', data: { status: '已完成', urgency: '不紧急', title: '测试程式 guardband 复核', owner: '王芳', due: '04-10', expect: '复核 guardband 设定是否过紧导致误判。', concl: '确认 guardband 偏紧约 0.3%，已修正并回归。', validity: '有效' } },
          { id: 'a3', kind: 'task', data: { status: '待接受', urgency: '紧急', title: '多 corner 条件重测验证', owner: '孙磊', due: '04-28', expect: '在 SS/FF/TT 三 corner 下重测确认一致性。', concl: '' } },
        ],
      },
      {
        id: 't2',
        kind: 'thought',
        data: { tag: '工艺', title: '怀疑边缘工艺异常导致良率呈环状掉点' },
        children: [
          { id: 'a4', kind: 'task', data: { status: '进行中', urgency: '紧急', title: 'Bin map 聚类与空间分布分析', owner: '赵敏', due: '04-25', expect: '对 fail bin 做空间聚类，定位异常 wafer 区域。', concl: '聚类显示边缘呈环状分布，指向边缘工艺。', validity: '部分有效' } },
          { id: 'a5', kind: 'task', data: { status: '进行中', urgency: '一般', title: 'Wafer 边缘膜厚量测复查', owner: '周涛', due: '04-26', expect: '量测边缘膜厚分布，比对中心区差异。', concl: '边缘膜厚偏薄约 4%，待进一步确认。', validity: '部分有效' } },
          {
            id: 't2a',
            kind: 'thought',
            data: { tag: '工艺·细化', title: '进一步怀疑边缘刻蚀均匀性不足' },
            children: [
              { id: 'a6', kind: 'task', data: { status: '待接受', urgency: '非常紧急', title: '刻蚀 profile SEM 复检', owner: '吴敏', due: '04-19', expect: '对边缘 die 做截面 SEM，检查刻蚀均匀性。', concl: '' } },
            ],
          },
        ],
      },
      {
        id: 't3',
        kind: 'thought',
        data: { tag: '量测', title: '怀疑 probe card 接触不良造成假性失效' },
        children: [
          { id: 'a7', kind: 'task', data: { status: '待接受', urgency: '非常紧急', title: 'FSA 失效点 EDS 成分复测', owner: '李娜', due: '04-18', expect: '对失效点做 EDS 成分分析，确认是否存在金属污染。', concl: '' } },
          { id: 'a8', kind: 'task', data: { status: '已完成', urgency: '一般', title: 'Probe card 接触电阻检查', owner: '郑昊', due: '04-12', expect: '测量各 pin 接触电阻，排查接触不良。', concl: '接触电阻正常，排除 probe card 因素。', validity: '有效' } },
        ],
      },
      {
        id: 't4',
        kind: 'thought',
        data: { tag: '设计', title: '怀疑设计 marginal，对边缘工艺波动敏感' },
        children: [
          { id: 'a9', kind: 'task', data: { status: '已中止', urgency: '一般', title: 'Shmoo plot 边界扫描', owner: '刘洋', due: '04-15', expect: '扫描电压/频率边界，定位 marginal 工作区。', concl: '因资源调整，任务中止。' } },
          { id: 'a10', kind: 'task', data: { status: '已拒绝', urgency: '紧急', title: 'SLT 高温复现实验', owner: '陈强', due: '04-20', expect: '在 105℃ 高温下尝试复现该失效模式。', concl: '经评估与失效模式不符，方向不成立。', validity: '无效' } },
        ],
      },
    ],
  }
}
