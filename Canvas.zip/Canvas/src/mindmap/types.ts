export type NodeKind = 'case' | 'thought' | 'task'

export type Status = '待接受' | '进行中' | '已拒绝' | '已完成' | '已中止'
export type Urgency = '非常紧急' | '紧急' | '一般' | '不紧急'
export type Validity = '有效' | '部分有效' | '无效' | ''
export type Level = 'L1' | 'L2' | 'L3' | 'L4' | 'L5'

export interface CaseData {
  level: Level
  code: string
  title: string
  site: string
  owner: string
}

export interface ThoughtData {
  tag: string
  title: string
}

export interface TaskData {
  status: Status
  urgency: Urgency
  title: string
  owner: string
  due: string
  expect: string
  concl?: string
  validity?: Validity
}

export type NodeData = CaseData | ThoughtData | TaskData

/** 思维导图的源数据：一棵嵌套树，是布局与渲染的唯一数据源 */
export interface TreeNode {
  id: string
  kind: NodeKind
  data: NodeData
  children?: TreeNode[]
  /** 是否收起：收起后其所有子孙节点不渲染 */
  collapsed?: boolean
}
