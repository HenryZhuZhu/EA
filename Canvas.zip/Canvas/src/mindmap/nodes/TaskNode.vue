<script setup lang="ts">
import { ref, computed } from 'vue'
import {
  Hourglass, Clock, Ban, Check, CircleSlash, ExternalLink,
  Pencil, Flag, Trash2, Plus, User, Calendar, ThumbsUp, MessageCircle,
  FileText, Image as ImageIcon, FileSpreadsheet,
} from 'lucide-vue-next'
import { useNode } from '../useNode'
import { actions } from '../useFlow'
import { STATUS, URG, VALIDITY, STATUS_OPTIONS, URGENCY_OPTIONS, VALIDITY_OPTIONS } from '../theme'
import type { TaskData } from '../types'
import CollapseToggle from './CollapseToggle.vue'

const root = ref<HTMLElement | null>(null)
const { id, data, isCandidate, measure, onHoverEnter, onHoverLeave } = useNode<TaskData>(root)

const STATUS_ICON: Record<string, any> = { Hourglass, Clock, Ban, Check, CircleSlash }
const s = computed(() => STATUS[data.value.status])
const u = computed(() => URG[data.value.urgency])

const editing = ref(false)
function toggleEdit() {
  editing.value = !editing.value
  measure()
}
function upd(patch: Partial<TaskData>) {
  actions.update?.(id, patch)
}

const DATA_FILES = [
  { icon: FileText, cls: 'text-rose-500', name: 'ICC2分析.pdf' },
  { icon: ImageIcon, cls: 'text-sky-500', name: 'wafermap.png' },
  { icon: FileSpreadsheet, cls: 'text-emerald-500', name: '良率.xlsx' },
]
</script>

<template>
  <div ref="root" class="relative">
    <div
      class="group card-lift bg-white border border-slate-200 border-l-[3px] rounded-lg p-2.5 shadow-sm hover:shadow-lg relative"
      :class="[u.stripe, isCandidate ? 'ring-2 ring-[#0052D9] ring-offset-2' : '']"
      @mouseenter="onHoverEnter"
      @mouseleave="onHoverLeave"
    >
    <!-- 顶部：任务标签 + 状态徽章 -->
    <div class="flex items-center justify-between mb-1.5">
      <span class="text-[9px] text-slate-400">任务</span>
      <span class="px-1.5 py-px rounded text-[9px] border inline-flex items-center gap-1" :class="s.badge">
        <component :is="STATUS_ICON[s.icon]" :size="10" /> {{ data.status }}
      </span>
    </div>

    <!-- 表单态：演示节点内嵌 Vue 表单（下拉 / 输入） -->
    <template v-if="editing">
      <input
        class="w-full mb-1 px-1.5 py-1 text-[12px] font-semibold border border-slate-300 rounded focus:outline-none focus:border-[#0052D9]"
        :value="data.title"
        @mousedown.stop
        @input="upd({ title: ($event.target as HTMLInputElement).value })"
      />
      <div class="grid grid-cols-2 gap-1 mb-1">
        <select class="ipt" :value="data.status" @mousedown.stop @change="upd({ status: ($event.target as HTMLSelectElement).value as any })">
          <option v-for="o in STATUS_OPTIONS" :key="o" :value="o">{{ o }}</option>
        </select>
        <select class="ipt" :value="data.urgency" @mousedown.stop @change="upd({ urgency: ($event.target as HTMLSelectElement).value as any })">
          <option v-for="o in URGENCY_OPTIONS" :key="o" :value="o">{{ o }}</option>
        </select>
        <input class="ipt" :value="data.owner" placeholder="负责人" @mousedown.stop @input="upd({ owner: ($event.target as HTMLInputElement).value })" />
        <input class="ipt" :value="data.due" placeholder="MM-DD" @mousedown.stop @input="upd({ due: ($event.target as HTMLInputElement).value })" />
        <select class="ipt col-span-2" :value="data.validity ?? ''" @mousedown.stop @change="upd({ validity: ($event.target as HTMLSelectElement).value as any })">
          <option v-for="o in VALIDITY_OPTIONS" :key="o" :value="o">{{ o === '' ? '结论有效性：未设置' : '结论' + o }}</option>
        </select>
      </div>
    </template>

    <!-- 展示态：三段式（动作标题 / 预期 / 结论） -->
    <template v-else>
      <div class="text-[12px] font-semibold text-slate-800 leading-snug line-clamp-2">{{ data.title }}</div>
      <div class="mt-1.5 flex items-start gap-1.5">
        <span class="shrink-0 text-[9px] text-slate-400 mt-px w-6">预期</span>
        <span class="flex-1 text-[10px] text-slate-600 leading-snug line-clamp-2">{{ data.expect }}</span>
      </div>
      <div class="mt-1 flex items-start gap-1.5">
        <span class="shrink-0 text-[9px] text-slate-400 mt-px w-6">结论</span>
        <div class="flex-1 min-w-0">
          <p v-if="data.concl" class="text-[10px] text-slate-600 leading-snug line-clamp-2">{{ data.concl }}</p>
          <span v-else class="text-[10px] text-slate-300">待补充</span>
          <div v-if="data.validity" class="mt-0.5">
            <button
              class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] border hover:brightness-95"
              :class="VALIDITY[data.validity]"
              title="查看 Workspace 笔记"
              @mousedown.stop
              @click.stop="actions.openWorkspace?.(id)"
            >
              结论{{ data.validity }} <ExternalLink :size="9" />
            </button>
          </div>
        </div>
      </div>
    </template>

    <!-- hover 展开浮层：负责人 / 预期完成 / 数据 / 点赞 + 工具栏 -->
    <div class="hv-more">
      <div class="mt-2 pt-2 border-t border-slate-200/70 space-y-1.5 text-[10px]">
        <div class="flex items-center justify-end gap-0.5">
          <button class="tb-btn" :class="editing ? 'text-[#0052D9] bg-slate-900/[0.06]' : ''" title="编辑" @mousedown.stop @click.stop="toggleEdit"><Pencil :size="11" /></button>
          <button class="tb-btn" title="标记整条线" @mousedown.stop @click.stop="actions.flagLine?.(id)"><Flag :size="11" /></button>
          <button class="tb-btn" title="删除" @mousedown.stop @click.stop="actions.remove?.(id)"><Trash2 :size="11" /></button>
          <button class="w-5 h-5 rounded-full bg-[#0052D9] text-white flex items-center justify-center hover:bg-[#003FA8]" title="基于此动作添加思路+任务" @mousedown.stop @click.stop="actions.addGroup?.(id)"><Plus :size="11" /></button>
        </div>
        <div class="flex items-center gap-1.5 text-slate-500"><User :size="11" /> 负责人：{{ data.owner }}</div>
        <div class="flex items-center gap-1.5 text-slate-500"><Calendar :size="11" /> 预期完成：{{ data.due }}</div>
        <div class="flex items-start gap-1.5">
          <span class="shrink-0 text-slate-400 pt-0.5">数据</span>
          <span class="flex flex-wrap gap-1">
            <span v-for="f in DATA_FILES" :key="f.name" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border bg-slate-50 border-slate-200 text-slate-600">
              <component :is="f.icon" :size="11" :class="f.cls" /> {{ f.name }}
            </span>
          </span>
        </div>
        <div class="flex items-center gap-3 pt-0.5">
          <span class="inline-flex items-center gap-1 text-[#0052D9]"><ThumbsUp :size="11" /> 3</span>
          <span class="inline-flex items-center gap-1 text-slate-400"><MessageCircle :size="11" /> 2</span>
        </div>
      </div>
    </div>
    </div>

    <!-- 收起/展开：左箭头，位于右侧连线汇聚处、紧邻节点外侧（与节点留间隙、不重合，避免误触卡片展开） -->
    <CollapseToggle
      :node-id="id"
      direction="left"
      class="absolute top-1/2 -right-7 -translate-y-1/2 z-10"
    />
  </div>
</template>

<style scoped>
.ipt {
  padding: 2px 6px;
  font-size: 11px;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  outline: none;
}
.ipt:focus {
  border-color: #0052d9;
}
</style>
