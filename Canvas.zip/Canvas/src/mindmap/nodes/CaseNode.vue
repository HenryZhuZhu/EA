<script setup lang="ts">
import { ref } from 'vue'
import { MapPin, Plus } from 'lucide-vue-next'
import { useNode } from '../useNode'
import { actions } from '../useFlow'
import { LEVEL } from '../theme'
import type { CaseData } from '../types'
import CollapseToggle from './CollapseToggle.vue'

const root = ref<HTMLElement | null>(null)
const { id, data, isCandidate } = useNode<CaseData>(root)

function addThought() {
  actions.addChild?.(id, 'thought')
}
</script>

<template>
  <div
    ref="root"
    class="group card-lift rounded-xl border-2 bg-white border-slate-300 p-3 shadow-lg relative"
    :class="isCandidate ? 'ring-2 ring-[#0052D9] ring-offset-2' : ''"
  >
    <div class="flex items-center gap-2 mb-1.5">
      <span class="px-2 py-0.5 rounded text-[10px] border" :class="LEVEL[data.level]">{{ data.level }}</span>
      <span class="text-[10px] text-slate-500">{{ data.code }}</span>
    </div>
    <div class="text-[13px] font-semibold text-slate-900 leading-snug">{{ data.title }}</div>
    <div class="mt-1.5 flex items-center gap-1.5 text-[10px] text-slate-500">
      <MapPin :size="11" /> {{ data.site }} · 负责人 {{ data.owner }}
    </div>

    <button
      class="absolute -right-2 -top-2 w-6 h-6 rounded-full bg-[#0052D9] text-white items-center justify-center shadow hover:bg-[#003FA8] hidden group-hover:flex"
      title="添加怀疑方向"
      @mousedown.stop
      @click.stop="addThought"
    >
      <Plus :size="13" />
    </button>

    <!-- 收起/展开：左箭头，位于右侧连线汇聚处、紧邻节点外侧（与节点留间隙、不重合） -->
    <CollapseToggle
      :node-id="id"
      direction="left"
      class="absolute top-1/2 -right-7 -translate-y-1/2 z-10"
    />
  </div>
</template>
