<script setup lang="ts">
import { ref } from 'vue'
import { Lightbulb, Pencil, Flag, Trash2, Plus, User, ThumbsUp, MessageCircle } from 'lucide-vue-next'
import { useNode } from '../useNode'
import { actions } from '../useFlow'
import type { ThoughtData } from '../types'
import CollapseToggle from './CollapseToggle.vue'

const root = ref<HTMLElement | null>(null)
const { id, data, isCandidate, measure, onHoverEnter, onHoverLeave } = useNode<ThoughtData>(root)

const editing = ref(false)
function toggleEdit() {
  editing.value = !editing.value
  measure()
}
function onInput(patch: Partial<ThoughtData>) {
  actions.update?.(id, patch)
}
</script>

<template>
  <div ref="root" class="relative">
    <div
      class="group card-lift flex bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm hover:shadow-lg relative"
      :class="isCandidate ? 'ring-2 ring-[#0052D9] ring-offset-2' : ''"
      @mouseenter="onHoverEnter"
      @mouseleave="onHoverLeave"
    >
    <div class="w-9 bg-amber-50 flex items-center justify-center shrink-0">
      <Lightbulb class="text-amber-500" :size="15" />
    </div>
    <div class="p-2.5 min-w-0 flex-1">
      <div class="text-[9px] text-amber-700 font-medium mb-1">思路 · {{ data.tag }}</div>

      <!-- 表单态：演示节点内嵌 Vue 表单组件 -->
      <template v-if="editing">
        <input
          class="w-full mb-1 px-1.5 py-1 text-[11px] border border-slate-300 rounded focus:outline-none focus:border-[#0052D9]"
          :value="data.tag"
          placeholder="方向标签"
          @mousedown.stop
          @input="onInput({ tag: ($event.target as HTMLInputElement).value })"
        />
        <textarea
          class="w-full px-1.5 py-1 text-[12px] border border-slate-300 rounded resize-none focus:outline-none focus:border-[#0052D9]"
          rows="3"
          :value="data.title"
          placeholder="怀疑方向描述"
          @mousedown.stop
          @input="onInput({ title: ($event.target as HTMLTextAreaElement).value })"
        />
      </template>
      <div v-else class="text-[12px] text-slate-700 leading-snug line-clamp-3">{{ data.title }}</div>

      <!-- hover 展开浮层（绝对定位，不挤压邻卡） -->
      <div class="hv-more">
        <div class="mt-2 pt-2 border-t border-slate-200/70 space-y-1.5 text-[10px]">
          <div class="flex items-center justify-end gap-0.5">
            <button class="tb-btn" title="编辑" @mousedown.stop @click.stop="toggleEdit"><Pencil :size="11" /></button>
            <button class="tb-btn" title="标记整条线" @mousedown.stop @click.stop="actions.flagLine?.(id)"><Flag :size="11" /></button>
            <button class="tb-btn" title="删除" @mousedown.stop @click.stop="actions.remove?.(id)"><Trash2 :size="11" /></button>
            <button class="w-5 h-5 rounded-full bg-[#0052D9] text-white flex items-center justify-center hover:bg-[#003FA8]" title="添加执行任务" @mousedown.stop @click.stop="actions.addChild?.(id, 'task')"><Plus :size="11" /></button>
          </div>
          <div class="flex items-center gap-1.5 text-slate-500"><User :size="11" /> 负责人：待指派</div>
          <div class="flex items-center gap-3">
            <span class="inline-flex items-center gap-1 text-amber-600"><ThumbsUp :size="11" /> 5</span>
            <span class="inline-flex items-center gap-1 text-slate-400"><MessageCircle :size="11" /> 1</span>
          </div>
        </div>
      </div>
    </div>
    </div>

    <!-- 收起/展开：上箭头，位于下方任务连线汇聚处（缩进槽主干 INDENT/2=20px），落在节点与首个任务之间预留的空隙中、与两者均不重合 -->
    <CollapseToggle
      :node-id="id"
      direction="up"
      class="absolute left-5 -bottom-6 -translate-x-1/2 z-10"
    />
  </div>
</template>
