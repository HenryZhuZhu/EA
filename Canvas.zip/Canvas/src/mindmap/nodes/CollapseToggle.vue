<script setup lang="ts">
import { computed } from 'vue'
import { ArrowLeft, ArrowUp } from 'lucide-vue-next'
import { nodeMeta, actions } from '../useFlow'

const props = defineProps<{
  nodeId: string
  /** 箭头方向：left（case/任务，子节点在右侧）/ up（思路，子节点在下方） */
  direction: 'left' | 'up'
}>()

const meta = computed(() => nodeMeta[props.nodeId])
const hasChildren = computed(() => (meta.value?.childCount ?? 0) > 0)
const collapsed = computed(() => !!meta.value?.collapsed)
const taskCount = computed(() => meta.value?.taskCount ?? 0)

function toggle() {
  actions.toggleCollapse?.(props.nodeId)
}
</script>

<template>
  <!-- 仅父节点（有子节点）显示。收起态显示子孙任务数，展开态显示方向箭头 -->
  <button
    v-if="hasChildren"
    class="collapse-btn"
    :class="direction === 'left' ? 'dir-left' : 'dir-up'"
    :title="collapsed ? `展开（${taskCount} 个任务）` : '收起'"
    @mousedown.stop
    @click.stop="toggle"
  >
    <span v-if="collapsed">{{ taskCount }}</span>
    <ArrowLeft v-else-if="direction === 'left'" :size="11" />
    <ArrowUp v-else :size="11" />
  </button>
</template>

<style scoped>
.collapse-btn {
  width: 20px;
  height: 20px;
  border-radius: 9999px;
  background: #fff;
  color: #0052d9;
  border: 1px solid #0052d9;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.12);
  cursor: pointer;
  padding: 0;
}
.collapse-btn:hover {
  background: #eff4ff;
}

/* 连接「节点 → 按钮」的短线，填补两者之间的空隙，使连线不断开 */
.collapse-btn::before {
  content: '';
  position: absolute;
  background: #cbd5e1;
}
/* 左箭头（case/任务）：按钮在节点右侧，短线向左连回节点 */
.collapse-btn.dir-left::before {
  right: 100%;
  top: 50%;
  width: 9px;
  height: 2px;
  transform: translateY(-50%);
}
/* 上箭头（思路）：按钮在节点下方，短线向上连回节点 */
.collapse-btn.dir-up::before {
  bottom: 100%;
  left: 50%;
  width: 2px;
  height: 6px;
  transform: translateX(-50%);
}
</style>
