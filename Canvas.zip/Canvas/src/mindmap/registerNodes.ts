import { register, getTeleport } from '@antv/x6-vue-shape'
import { SIZE, shapeOf } from './theme'
import CaseNode from './nodes/CaseNode.vue'
import ThoughtNode from './nodes/ThoughtNode.vue'
import TaskNode from './nodes/TaskNode.vue'

let registered = false

/** 把三类卡片注册为 X6 的 Vue 节点（节点本体即一个完整 Vue3 组件） */
export function registerMindMapNodes() {
  if (registered) return
  registered = true

  register({ shape: shapeOf.case, width: SIZE.case.width, height: SIZE.case.height, component: CaseNode })
  register({ shape: shapeOf.thought, width: SIZE.thought.width, height: SIZE.thought.height, component: ThoughtNode })
  register({ shape: shapeOf.task, width: SIZE.task.width, height: SIZE.task.height, component: TaskNode })
}

/** x6-vue-shape 的传送门容器组件，需在 App 模板中渲染一次 */
export const TeleportContainer = getTeleport()
