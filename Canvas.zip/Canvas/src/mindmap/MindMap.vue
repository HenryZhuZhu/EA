<script setup lang="ts">
import { Undo2, Redo2, ZoomIn, ZoomOut, Maximize, RotateCcw } from 'lucide-vue-next'
import { registerMindMapNodes, TeleportContainer } from './registerNodes'
import { useFlow } from './useFlow'

// 在创建画布前注册 Vue 节点（useFlow 不再依赖 registerNodes，避免与节点组件循环引用）
registerMindMapNodes()

const { containerEl, minimapEl, undo, redo, zoomIn, zoomOut, fit, reset } = useFlow()
</script>

<template>
  <div class="relative w-full h-full">
    <!-- 工具栏 -->
    <div class="absolute z-20 left-3 top-3 flex items-center gap-1 bg-white/90 backdrop-blur border border-slate-200 rounded-lg shadow-sm px-1.5 py-1">
      <button class="bar-btn" title="撤销 (Ctrl+Z)" @click="undo"><Undo2 :size="15" /></button>
      <button class="bar-btn" title="重做 (Ctrl+Shift+Z)" @click="redo"><Redo2 :size="15" /></button>
      <span class="w-px h-4 bg-slate-200 mx-0.5" />
      <button class="bar-btn" title="放大" @click="zoomIn"><ZoomIn :size="15" /></button>
      <button class="bar-btn" title="缩小" @click="zoomOut"><ZoomOut :size="15" /></button>
      <button class="bar-btn" title="适应画布" @click="fit"><Maximize :size="15" /></button>
      <button class="bar-btn" title="重置示例" @click="reset"><RotateCcw :size="15" /></button>
    </div>

    <!-- 操作提示 -->
    <div class="absolute z-20 right-3 top-3 text-[11px] text-slate-400 bg-white/80 rounded px-2 py-1 border border-slate-200">
      拖动节点到目标卡片上 = 改其父级 · 滚轮缩放 · 空白拖拽平移 · Shift+框选
    </div>

    <!-- 画布 -->
    <div ref="containerEl" class="w-full h-full" />

    <!-- 小地图 -->
    <div ref="minimapEl" class="absolute z-20 right-3 bottom-3 rounded-lg border border-slate-200 shadow-sm overflow-hidden bg-white" />

    <!-- x6-vue-shape 传送门容器 -->
    <TeleportContainer />
  </div>
</template>

<style scoped>
.bar-btn {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #475569;
}
.bar-btn:hover {
  background: #f1f5f9;
  color: #0052d9;
}
</style>
