import { inject, ref, computed, onMounted, onBeforeUnmount, nextTick, watch, type Ref } from 'vue'
import { dragUI, actions } from './useFlow'

/**
 * 节点组件通用逻辑：
 * - 取得当前 X6 节点、暴露其 data（随 change:data 自动刷新）
 * - 计算「是否为拖拽落点候选父节点」用于高亮
 * - measure()：把 DOM 折叠态高度上报给画布，触发 resize + 重新布局
 * - onHoverEnter/onHoverLeave：悬停展开时把节点高度计入布局并重新布局，
 *   下方/同组节点自动让开，不被展开浮层覆盖（统一走布局，避免位移错乱）
 */
export function useNode<T = any>(rootEl: Ref<HTMLElement | null>) {
  const getNode = inject<() => any>('getNode')!
  const node = getNode()
  const id: string = node.id

  const data = ref<T>({ ...(node.getData() ?? {}) }) as Ref<T>
  const onChange = () => {
    data.value = { ...(node.getData() ?? {}) }
  }
  node.on('change:data', onChange)
  onBeforeUnmount(() => node.off('change:data', onChange))

  const isCandidate = computed(() => dragUI.candidateId === id)
  const isDragging = computed(() => dragUI.draggingId === id)

  /** 当前是否处于悬停展开态 */
  let hovered = false

  const HV_MAX = 260 // 与 style.css 中 .hv-more 的 max-height 一致

  /**
   * 上报当前应有的布局高度并触发重排。
   * 基础高度（不含悬停浮层）= 卡片高 − 浮层当前高度，
   * 在「展示/编辑 × 悬停/未悬停 × 过渡中」任意组合下都成立，避免缓存被污染：
   * 卡片高度始终等于「基础内容 + 浮层当前高度」。
   */
  function report() {
    nextTick(() => {
      const el = rootEl.value
      if (!el) return
      const panel = el.querySelector('.hv-more') as HTMLElement | null
      // offsetHeight 为布局坐标，不受画布缩放 transform 影响
      const base = el.offsetHeight - (panel?.offsetHeight ?? 0)
      if (base <= 0) return
      const extra = hovered && panel ? Math.min(panel.scrollHeight, HV_MAX) + 6 : 0
      actions.reportHeight?.(id, base + extra)
    })
  }

  /** 编辑表单展开/折叠后由组件调用，按当前真实高度重排 */
  function measure() {
    report()
  }

  /** 悬停展开：把浮层高度计入节点高度并重排，下方/同组节点自动让开 */
  function onHoverEnter() {
    if (dragUI.draggingId) return // 拖拽中不触发悬停布局，避免与拖拽相互干扰
    hovered = true
    report()
  }

  /** 离开：恢复到当前基础高度（含编辑态）并重排，连线点随之重新居中 */
  function onHoverLeave() {
    if (dragUI.draggingId) return
    hovered = false
    report()
  }

  onMounted(() => report())

  return { node, id, data, isCandidate, isDragging, measure, onHoverEnter, onHoverLeave, watch }
}
