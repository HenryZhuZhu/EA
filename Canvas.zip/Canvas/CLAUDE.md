# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

- `npm run dev` — start Vite dev server at http://localhost:5173 (auto-opens browser)
- `npm run build` — type-check with `vue-tsc` then production build to `dist/`
- `npm run preview` — serve the built `dist/`

There is no test runner or linter configured. To sanity-check a change compiles across all modules, run `npx vite build` (rollup link step surfaces missing imports/exports that the dev server's esbuild transform silently tolerates — e.g. a wrong lucide icon name).

## What this is

A Vue 3 + TypeScript mind-map built on **AntV X6** (v2). It renders an EA-domain tree: one **Case** (root) → multiple **Thought** nodes (怀疑方向) → **Action** nodes (执行任务), with thoughts nestable arbitrarily deep. Each node is a real Vue component (not canvas-drawn), so cards carry rich DOM: status/urgency badges, hover-expand detail panels, toolbars, and inline edit forms.

X6 renders via SVG, not canvas. This was a deliberate trade-off to allow Vue-component nodes + drag-to-reparent; at this node count SVG performance is a non-issue. The dot-grid background and pan/zoom give it a canvas-like feel.

## Architecture

Everything lives under `src/mindmap/`. The key idea: **`tree` (a nested `TreeNode`) is the single source of truth**, and the X6 graph is a derived view kept in sync from it.

- **`MindMap.vue`** — the orchestrator and the only file that touches the X6 `Graph`. It owns the `tree` ref, creates the graph + plugins, and exposes the toolbar. Two functions drive everything:
  - `syncGraph()` — reconciles graph nodes/edges against `tree` (add missing, remove stale, rebuild all edges), then calls `applyLayout()`. Call this after any **structural** change.
  - `applyLayout()` — recomputes positions via `computeLayout` and `setPosition`/`resize`s each node. Call this after **position/size-only** changes (e.g. a node's height changed).
- **`store.ts`** — the bridge between leaf node components and the graph. `actions` is a `Partial<MindMapActions>` object that `MindMap.vue` populates in `registerActions()`; node components import `actions` and call `actions.update/addChild/remove/...` without knowing anything about X6. Also holds `dragUI` (reactive drag state read by nodes for highlight) and the pure tree-walking helpers (`findNode`, `findParent`, `collectSubtreeIds`, etc.).
- **`useNode.ts`** — composable every node component uses. Injects the X6 node (`inject('getNode')`), exposes its `data` as a ref that re-syncs on `change:data`, computes `isCandidate` (drag highlight) from `dragUI`, and provides `measure()` which reports the rendered DOM height back via `actions.reportHeight` so the layout can account for expanded forms.
- **`registerNodes.ts`** — registers the three shapes with `@antv/x6-vue-shape` (`case-node`/`thought-node`/`action-node`) and exports `TeleportContainer`, which **must be rendered once** in the template (it is, in `MindMap.vue`) for vue-shape nodes to mount.
- **`layout.ts`** — wraps `@antv/hierarchy` `compactBox` (tidy-tree, direction `LR`). Node sizes come from `SIZE` in `theme.ts`, overridable per-id via the `heights` map. Output coordinates are normalized to positive space with padding.
- **`theme.ts`** — all color maps (`STATUS`/`URG`/`LEVEL`/`VALIDITY`) as Tailwind class strings, plus `SIZE` (per-kind card dimensions used by the layout) and the form `*_OPTIONS` arrays.
- **`nodes/*.vue`** — the three card components. `ActionNode.vue` is the richest (three-section display, hover-expand panel, inline edit form). Styling reuses Tailwind via CDN (see below).

### Data flow rules

- Mutate `tree` → call `syncGraph()` (structure) or `applyLayout()` (positions). Never mutate X6 nodes as the source of truth.
- Node edits go through `actions.update(id, patch)`, which writes to both the `tree` data object and the X6 node's data (`setData`) so `useNode`'s `change:data` listener refreshes the component.
- Any interactive element inside a node (button, input, select) **must** have `@mousedown.stop` — otherwise X6 interprets the press as a node drag / canvas pan.

### Drag-to-reparent

Implemented in `MindMap.vue` via `node:mousedown` (record pre-drag subtree positions) → `node:moving` (whole subtree follows the cursor; `detectCandidate` uses `graph.getNodesUnderNode(node, {by:'bbox'})` to find the nearest overlapping node as the new-parent candidate and sets `dragUI.candidateId` for highlight) → `node:moved` (`reparent` mutates `tree` and `syncGraph`s, or snaps back). `reparent` rejects cycles by excluding the dragged node's own subtree (`collectSubtreeIds`).

## Conventions / gotchas

- **Adding a node kind**: add to `NodeKind`/`SIZE`/`shapeOf`, create the `.vue` component, and register it in `registerNodes.ts`. The component should use `useNode` and gate interactive elements with `@mousedown.stop`.
- **Tailwind is loaded via CDN** in `index.html` (so templates can use utility classes directly). Class strings in `theme.ts` therefore have no build-time safelisting. For production, replace the CDN with a real Tailwind build. Truly custom classes (`.hv-more`, `.card-lift`, `.tb-btn`) live in `src/style.css`, not Tailwind.
- **Hover-expand overlay** (`.hv-more`) relies on `overflow: visible` on the X6 `foreignObject` (set in `src/style.css`) and `node.setZIndex(1000)` on `node:mouseenter` so the expanded panel isn't clipped or covered by neighbors.
- **Version pinning**: the stack is intentionally all-X6-**v2** (`@antv/x6` ^2.x, `x6-vue-shape` ^2.x, plugins ^2.x, `@antv/hierarchy` ^0.6.x). X6 v3 / vue-shape v3 exist but their peer deps conflict with the v2 plugins — do not bump piecemeal.
