# EA · Easy Analysis — 落地页（可直接部署）

自包含的静态首页,**不依赖任何构建、框架或后端**。整个目录就是部署产物。

```
ea-landing/
├── index.html      # 首页（内联 CSS/JS）
└── assets/         # 页面引用的 4 张产品截图
```

## 本地预览

直接双击 `index.html`,或用任意静态服务器:

```bash
npx serve .        # 或： python3 -m http.server
```

## 部署

把整个 `ea-landing/` 目录上传到任意静态托管即可(Netlify / Vercel / GitHub Pages / 对象存储 / Nginx 等),入口为 `index.html`。

> 注:`index.html` 用相对路径 `assets/...` 引用图片,务必连同 `assets/` 一起拷贝。
