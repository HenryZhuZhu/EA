import { ref, type Ref } from 'vue'
import type { Graph, Node } from '@antv/x6'

/**
 * 节点文本编辑与「文本插入」光标模式。
 */
export function useNodeEditing(graph: Ref<Graph | null>, canvasRef: Ref<HTMLElement | null>) {
  const textMode = ref(false)

  function enterTextMode() {
    textMode.value = true
    const c = graph.value?.container
    if (c) c.style.cursor = 'text'
  }

  function exitTextMode() {
    textMode.value = false
    const c = graph.value?.container
    if (c) c.style.cursor = ''
  }

  /** 通过输入框就地编辑节点文本 */
  function editNodeLabel(node: Node) {
    const g = graph.value
    const host = canvasRef.value
    if (!g || !host) return
    const view = g.findViewByCell(node)
    if (!view) return

    const { x, y, width } = node.getBBox()
    const point = g.localToGraph({ x, y })
    const scale = g.zoom()

    const input = document.createElement('input')
    const current =
      (node as unknown as { label?: string }).label ||
      (node.attr('text/text') as string) ||
      (node.getAttrByPath('label/text') as string) ||
      ''
    input.value = current
    Object.assign(input.style, {
      position: 'absolute',
      left: `${point.x}px`,
      top: `${point.y}px`,
      width: `${width * scale}px`,
      height: '26px',
      zIndex: '100',
      border: '1px solid #3370ff',
      borderRadius: '4px',
      padding: '0 6px',
      fontSize: '13px',
      outline: 'none',
      textAlign: 'center'
    })
    host.appendChild(input)
    input.focus()
    input.select()

    const commit = () => {
      // 空字符：移除文本（setLabel(null) 会清空），避免残留占位符
      // setLabel 由 X6 节点 Base 类在运行时提供，但未在 Node 类型上暴露
      const labelable = node as unknown as { setLabel(text: string | null): void }
      labelable.setLabel(input.value === '' ? null : input.value)
      input.remove()
    }
    input.addEventListener('blur', commit)
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') input.blur()
      if (e.key === 'Escape') input.remove()
    })
  }

  return { textMode, enterTextMode, exitTextMode, editNodeLabel }
}
