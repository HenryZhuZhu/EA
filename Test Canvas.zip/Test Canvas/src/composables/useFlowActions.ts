import type { Ref } from 'vue'
import type { Graph } from '@antv/x6'
import type { FlowAction } from '../flow/types'

interface ActionHooks {
  /** 画布空/非空状态刷新 */
  refreshEmpty: () => void
  /** 保存完成回调（用于切换到预览缩略模式；数据已通过 v-model 实时上抛） */
  onSaved: () => void
}

/**
 * 工具栏 / 右键菜单动作分发。
 */
export function useFlowActions(graph: Ref<Graph | null>, hooks: ActionHooks) {
  function exportJSON(g: Graph) {
    const data = JSON.stringify(g.toJSON(), null, 2)
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `flow-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  function onAction(action: FlowAction) {
    const g = graph.value
    if (!g) return

    switch (action) {
      case 'undo':
        if (g.canUndo()) g.undo()
        break
      case 'redo':
        if (g.canRedo()) g.redo()
        break
      case 'zoomIn':
        g.zoom(0.1)
        break
      case 'zoomOut':
        g.zoom(-0.1)
        break
      case 'fit':
        g.zoomToFit({ padding: 40, maxScale: 1.5 })
        break
      case 'reset':
        g.zoomTo(1)
        g.centerContent()
        break
      case 'copy': {
        const cells = g.getSelectedCells()
        if (cells.length) g.copy(cells)
        break
      }
      case 'paste':
        if (!g.isClipboardEmpty()) {
          const cells = g.paste({ offset: 32 })
          g.cleanSelection()
          g.select(cells)
        }
        break
      case 'delete': {
        const cells = g.getSelectedCells()
        if (cells.length) g.removeCells(cells)
        break
      }
      case 'selectAll':
        g.select(g.getCells())
        break
      case 'toFront':
        g.getSelectedCells().forEach((c) => c.toFront())
        break
      case 'toBack':
        g.getSelectedCells().forEach((c) => c.toBack())
        break
      case 'clear':
        if (confirm('确定清空整个画布吗？')) {
          g.clearCells()
          hooks.refreshEmpty()
        }
        break
      case 'save':
        hooks.onSaved()
        break
      case 'export':
        exportJSON(g)
        break
    }
  }

  return { onAction }
}
