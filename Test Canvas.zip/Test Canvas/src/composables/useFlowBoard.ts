import { nextTick, ref, shallowRef } from 'vue'
import { Dnd } from '@antv/x6-plugin-dnd'
import type { Cell, Edge, Graph } from '@antv/x6'
import { createGraph } from '../flow/graph'
import type { FlowAction, GraphData } from '../flow/types'
import { useContextMenu } from './useContextMenu'
import { useNodeEditing } from './useNodeEditing'
import { useFlowActions } from './useFlowActions'
import { useImageUpload } from './useImageUpload'

interface FlowBoardOptions {
  /** 读取初始化数据（v-model 的初值），用于首次渲染 */
  getData?: () => GraphData | null | undefined
  /** 画布内容实时变化回调（用于 v-model 双向绑定） */
  onChange?: (data: GraphData) => void
  /** 保存完成后的回调（用于切换到预览缩略模式） */
  onSaved?: () => void
}

/**
 * 画板主逻辑：创建画布、装配交互、组合各功能 hooks，
 * 对外暴露头部工具栏 / 左侧图形面板 / 右侧画布所需的状态与方法。
 *
 * 数据流：初始化时读取 getData()，编辑过程中通过 onChange 实时上抛，
 * 支持宿主以 v-model 双向绑定。画布 DOM 归属「右侧主画布」组件，
 * 画布创建/销毁通过 initGraph / disposeGraph 由宿主在挂载/卸载时驱动。
 */
export function useFlowBoard(options: FlowBoardOptions = {}) {
  const graph = shallowRef<Graph | null>(null)
  const dnd = shallowRef<Dnd | null>(null)
  const zoom = ref(1)
  const isEmpty = ref(true)
  const selectedCells = shallowRef<Cell[]>([])
  const canvasEl = ref<HTMLElement | null>(null)

  // 记录最近一次上抛的数据（用于识别并忽略 v-model 回流造成的“回声”）
  let lastEmitted = ''
  // 正在把外部数据写入画布，期间不触发 onChange，避免回声/循环
  let applyingModel = false
  let emitScheduled = false

  const { menu, menuItems, open: openMenu, hide: hideMenu } = useContextMenu(graph)
  const { textMode, enterTextMode, exitTextMode, editNodeLabel } = useNodeEditing(graph, canvasEl)
  const { triggerImageUpload } = useImageUpload()

  function refreshEmpty() {
    isEmpty.value = graph.value ? graph.value.getCells().length === 0 : true
  }

  const { onAction } = useFlowActions(graph, {
    refreshEmpty,
    onSaved: () => options.onSaved?.()
  })

  function onMenuSelect(action: FlowAction) {
    hideMenu()
    onAction(action)
  }

  // 判断数据是否为“非空”（含至少一个 cell）
  function hasCells(data: GraphData | null | undefined): boolean {
    return !!data && Array.isArray((data as { cells?: unknown[] }).cells) &&
      (data as { cells: unknown[] }).cells.length > 0
  }

  // 序列化并实时上抛当前画布内容
  function emitChange() {
    if (applyingModel || !graph.value) return
    const data = graph.value.toJSON()
    lastEmitted = JSON.stringify(data)
    options.onChange?.(data)
  }

  // 合并同一同步栈内的多次变化，避免频繁上抛（用微任务，不受标签页可见性影响）
  function scheduleEmit() {
    if (applyingModel || emitScheduled) return
    emitScheduled = true
    Promise.resolve().then(() => {
      emitScheduled = false
      emitChange()
    })
  }

  // 把外部数据写入画布（不触发 onChange）
  function applyData(data: GraphData | null | undefined) {
    const g = graph.value
    if (!g) return
    applyingModel = true
    if (hasCells(data)) {
      g.fromJSON(data as never)
    } else {
      g.clearCells()
    }
    applyingModel = false
    refreshEmpty()
  }

  /** 宿主 watch(modelValue) 时调用：外部数据变化才写回画布，忽略自身回声 */
  function syncFromModel(data: GraphData | null | undefined) {
    if (!graph.value) return
    const incoming = JSON.stringify(data ?? {})
    if (incoming === lastEmitted) return
    applyData(data)
  }

  // 连线选中时，在两端挂载可拖拽的端点锚点（拖动可伸缩/旋转/重连）
  function addEdgeTools(edge: Edge) {
    const anchorAttrs = {
      r: 6,
      fill: '#ffffff',
      stroke: '#3370ff',
      'stroke-width': 2,
      cursor: 'move'
    }
    edge.addTools([
      { name: 'source-arrowhead', args: { tagName: 'circle', attrs: anchorAttrs } },
      { name: 'target-arrowhead', args: { tagName: 'circle', attrs: anchorAttrs } }
    ])
  }

  function onKeydown(e: KeyboardEvent) {
    if (e.key === 'Escape' && textMode.value) exitTextMode()
  }

  /** 触发图片上传并插入图片节点 */
  function uploadImage() {
    if (graph.value) triggerImageUpload(graph.value)
  }

  /** 由「右侧主画布」组件在挂载后调用，完成画布初始化 */
  function initGraph(canvas: HTMLElement, minimap?: HTMLElement | null) {
    canvasEl.value = canvas
    const g = createGraph(canvas, minimap)
    graph.value = g

    dnd.value = new Dnd({ target: g, scaled: false })

    // 双击节点进入文本编辑（图片节点跳过）
    g.on('node:dblclick', ({ node }) => {
      if (node.shape !== 'basic-image') editNodeLabel(node)
    })

    g.on('scale', ({ sx }) => (zoom.value = sx))

    // 内容变化 -> 刷新空状态 + 实时上抛（v-model）
    g.on('cell:added', () => {
      refreshEmpty()
      scheduleEmit()
    })
    g.on('cell:removed', () => {
      refreshEmpty()
      scheduleEmit()
    })
    g.on('cell:change:*', scheduleEmit)

    // 选区变化 -> 驱动格式面板；连线选中时挂载端点锚点工具
    g.on('selection:changed', ({ added, removed, selected }) => {
      selectedCells.value = selected
      added.forEach((c) => c.isEdge() && addEdgeTools(c as Edge))
      removed.forEach((c) => c.isEdge() && c.removeTools())
    })

    // 右键菜单
    g.on('node:contextmenu', ({ e, node }) => openMenu(e, 'cell', node))
    g.on('edge:contextmenu', ({ e, edge }) => openMenu(e, 'cell', edge))
    g.on('blank:contextmenu', ({ e }) => openMenu(e, 'blank'))
    g.on('cell:click blank:click cell:mousedown blank:mousedown', hideMenu)
    g.on('scale translate', hideMenu)

    // 文本插入模式：在空白处点击落点创建文本并进入编辑
    g.on('blank:click', ({ x, y }) => {
      if (!textMode.value) return
      const node = g.addNode({
        shape: 'basic-text',
        x: x - 50,
        y: y - 14,
        width: 100,
        height: 28,
        label: ''
      })
      exitTextMode()
      nextTick(() => editNodeLabel(node))
    })

    loadInitial(g)

    window.addEventListener('click', hideMenu)
    window.addEventListener('keydown', onKeydown)
  }

  // 首次载入：有初始数据则渲染，否则生成示例流程；随后上抛一次以同步 v-model
  function loadInitial(g: Graph) {
    const initial = options.getData?.()
    applyingModel = true
    if (hasCells(initial)) {
      g.fromJSON(initial as never)
    } else {
      createSample(g)
    }
    applyingModel = false
    refreshEmpty()
    emitChange()
    // 容器尺寸在挂载帧后才稳定，延迟一拍再居中，避免按 0 尺寸计算导致偏移
    setTimeout(() => graph.value?.centerContent(), 0)
  }

  /** 由宿主组件在卸载前调用，释放资源 */
  function disposeGraph() {
    window.removeEventListener('click', hideMenu)
    window.removeEventListener('keydown', onKeydown)
    graph.value?.dispose()
    graph.value = null
    dnd.value = null
  }

  // 初始示例流程
  function createSample(g: Graph) {
    const start = g.addNode({ shape: 'flow-terminal', x: 340, y: 80, label: '开始' })
    const process = g.addNode({ shape: 'flow-process', x: 330, y: 180, label: '收集需求' })
    const decision = g.addNode({ shape: 'flow-decision', x: 330, y: 300, label: '需求明确?' })
    const data = g.addNode({ shape: 'flow-data', x: 520, y: 310, label: '补充调研' })
    const end = g.addNode({ shape: 'flow-terminal', x: 340, y: 440, label: '结束' })

    g.addEdge({ shape: 'flow-edge', source: start, target: process })
    g.addEdge({ shape: 'flow-edge', source: process, target: decision })
    g.addEdge({
      shape: 'flow-edge',
      source: decision,
      target: end,
      labels: [{ attrs: { label: { text: '是' } } }]
    })
    g.addEdge({
      shape: 'flow-edge',
      source: decision,
      target: data,
      labels: [{ attrs: { label: { text: '否' } } }]
    })
    g.addEdge({ shape: 'flow-edge', source: data, target: process })
    g.centerContent()
    refreshEmpty()
  }

  return {
    // 画布实例与拖拽源
    graph,
    dnd,
    // 状态
    zoom,
    isEmpty,
    selectedCells,
    textMode,
    menu,
    menuItems,
    // 生命周期
    initGraph,
    disposeGraph,
    syncFromModel,
    // 方法
    onAction,
    onMenuSelect,
    enterTextMode,
    uploadImage
  }
}
