import { computed, reactive, type Ref } from 'vue'
import type { Cell, Graph } from '@antv/x6'
import type { MenuItem, MenuTargetType } from '../flow/types'

/**
 * 右键菜单状态管理：维护位置/可见性，并按目标类型给出菜单项。
 */
export function useContextMenu(graph: Ref<Graph | null>) {
  const menu = reactive({
    visible: false,
    x: 0,
    y: 0,
    type: 'blank' as MenuTargetType
  })

  const menuItems = computed<MenuItem[]>(() => {
    const g = graph.value
    if (menu.type === 'cell') {
      return [
        { label: '复制', action: 'copy', shortcut: '⌘C' },
        { label: '删除', action: 'delete', shortcut: 'Del', danger: true },
        { divider: true },
        { label: '置于顶层', action: 'toFront' },
        { label: '置于底层', action: 'toBack' }
      ]
    }
    return [
      { label: '粘贴', action: 'paste', shortcut: '⌘V', disabled: !g || g.isClipboardEmpty() },
      { label: '全选', action: 'selectAll', shortcut: '⌘A' },
      { divider: true },
      { label: '适应画布', action: 'fit' },
      { label: '清空画布', action: 'clear', danger: true }
    ]
  })

  function open(e: { clientX: number; clientY: number }, type: MenuTargetType, cell?: Cell) {
    const g = graph.value
    if (g && cell && !g.isSelected(cell)) {
      g.cleanSelection()
      g.select(cell)
    }
    menu.type = type
    menu.x = e.clientX
    menu.y = e.clientY
    menu.visible = true
  }

  function hide() {
    menu.visible = false
  }

  return { menu, menuItems, open, hide }
}
