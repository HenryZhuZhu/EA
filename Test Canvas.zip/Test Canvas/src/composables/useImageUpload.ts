import type { Graph, Node } from '@antv/x6'

// 上传图片自动缩放到该最大边长，避免超大图占满画布
const MAX_SIZE = 320

/**
 * 图片上传：选择本地图片 -> 读取为 DataURL -> 作为图片节点插入画布。
 * 图片节点支持四角缩放、旋转、拖动与四向连线（由画布 Transform 插件与连接桩提供）。
 */
export function useImageUpload() {
  function pickImage(): Promise<File | null> {
    return new Promise((resolve) => {
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = 'image/*'
      input.onchange = () => resolve(input.files?.[0] ?? null)
      input.click()
    })
  }

  function readAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(reader.result as string)
      reader.onerror = reject
      reader.readAsDataURL(file)
    })
  }

  function loadImageSize(url: string): Promise<{ width: number; height: number }> {
    return new Promise((resolve) => {
      const img = new Image()
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight })
      img.onerror = () => resolve({ width: 160, height: 120 })
      img.src = url
    })
  }

  /** 将图片文件作为节点添加到画布中央并选中 */
  async function addImageNode(graph: Graph, file: File): Promise<Node | null> {
    if (!file.type.startsWith('image/')) return null
    const url = await readAsDataURL(file)
    const { width, height } = await loadImageSize(url)
    const ratio = Math.min(1, MAX_SIZE / Math.max(width, height))
    const w = Math.round(width * ratio) || 160
    const h = Math.round(height * ratio) || 120

    const area = graph.getGraphArea()
    const node = graph.addNode({
      shape: 'basic-image',
      x: area.x + area.width / 2 - w / 2,
      y: area.y + area.height / 2 - h / 2,
      width: w,
      height: h,
      attrs: { image: { 'xlink:href': url } }
    })
    graph.cleanSelection()
    graph.select(node)
    return node
  }

  /** 触发文件选择并插入图片节点 */
  async function triggerImageUpload(graph: Graph): Promise<void> {
    const file = await pickImage()
    if (file) await addImageNode(graph, file)
  }

  return { triggerImageUpload, addImageNode }
}
