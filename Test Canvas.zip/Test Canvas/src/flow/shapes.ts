import { Graph, Shape } from '@antv/x6'

// 统一的连接桩配置（上下左右四个方向）
const portCircle = {
  r: 4,
  magnet: true,
  stroke: '#3370ff',
  strokeWidth: 1,
  fill: '#fff',
  style: { visibility: 'hidden' }
}

const PORT_GROUPS = {
  top: { position: 'top', attrs: { circle: { ...portCircle } } },
  right: { position: 'right', attrs: { circle: { ...portCircle } } },
  bottom: { position: 'bottom', attrs: { circle: { ...portCircle } } },
  left: { position: 'left', attrs: { circle: { ...portCircle } } }
}

const defaultPorts = () => ({
  groups: PORT_GROUPS,
  items: [
    { id: 'top', group: 'top' },
    { id: 'right', group: 'right' },
    { id: 'bottom', group: 'bottom' },
    { id: 'left', group: 'left' }
  ]
})

const baseLabelAttrs = {
  text: {
    fontSize: 13,
    fill: '#1f2329'
  }
}

// 开始 / 结束：圆角胶囊
Graph.registerNode(
  'flow-terminal',
  {
    inherit: 'rect',
    width: 100,
    height: 40,
    attrs: {
      body: {
        rx: 20,
        ry: 20,
        stroke: '#00c6a7',
        strokeWidth: 1.5,
        fill: '#e6fffb'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// 处理步骤：矩形
Graph.registerNode(
  'flow-process',
  {
    inherit: 'rect',
    width: 120,
    height: 48,
    attrs: {
      body: {
        rx: 6,
        ry: 6,
        stroke: '#3370ff',
        strokeWidth: 1.5,
        fill: '#eef3ff'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// 判断：菱形
Graph.registerNode(
  'flow-decision',
  {
    inherit: 'polygon',
    width: 120,
    height: 70,
    attrs: {
      body: {
        refPoints: '0,10 10,0 20,10 10,20',
        stroke: '#ff8f1f',
        strokeWidth: 1.5,
        fill: '#fff7e6'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// 数据 / 输入输出：平行四边形
Graph.registerNode(
  'flow-data',
  {
    inherit: 'polygon',
    width: 120,
    height: 48,
    attrs: {
      body: {
        refPoints: '20,0 100,0 80,20 0,20',
        stroke: '#8f5eff',
        strokeWidth: 1.5,
        fill: '#f4edff'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// 文档：底部波浪矩形
Graph.registerNode(
  'flow-document',
  {
    inherit: 'path',
    width: 120,
    height: 56,
    attrs: {
      body: {
        refD: 'M 0 0 L 100 0 L 100 80 C 75 65 50 95 25 80 C 12 72 6 76 0 80 Z',
        stroke: '#3370ff',
        strokeWidth: 1.5,
        fill: '#eef3ff'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// 准备：六边形
Graph.registerNode(
  'flow-preparation',
  {
    inherit: 'polygon',
    width: 120,
    height: 56,
    attrs: {
      body: {
        refPoints: '25,0 75,0 100,50 75,100 25,100 0,50',
        stroke: '#00c6a7',
        strokeWidth: 1.5,
        fill: '#e6fffb'
      },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

// ============ 基础图形（中性白底灰边） ============
const basicBody = {
  stroke: '#4e5969',
  strokeWidth: 1.5,
  fill: '#ffffff'
}

Graph.registerNode(
  'basic-rect',
  {
    inherit: 'rect',
    width: 100,
    height: 60,
    attrs: { body: { ...basicBody }, ...baseLabelAttrs },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-round',
  {
    inherit: 'rect',
    width: 100,
    height: 60,
    attrs: { body: { ...basicBody, rx: 12, ry: 12 }, ...baseLabelAttrs },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-ellipse',
  {
    inherit: 'ellipse',
    width: 110,
    height: 66,
    attrs: { body: { ...basicBody }, ...baseLabelAttrs },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-circle',
  {
    inherit: 'ellipse',
    width: 80,
    height: 80,
    attrs: { body: { ...basicBody }, ...baseLabelAttrs },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-diamond',
  {
    inherit: 'polygon',
    width: 100,
    height: 80,
    attrs: {
      body: { ...basicBody, refPoints: '0,10 10,0 20,10 10,20' },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-parallelogram',
  {
    inherit: 'polygon',
    width: 110,
    height: 60,
    attrs: {
      body: { ...basicBody, refPoints: '20,0 100,0 80,20 0,20' },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-triangle',
  {
    inherit: 'polygon',
    width: 90,
    height: 76,
    attrs: {
      body: { ...basicBody, refPoints: '10,0 20,20 0,20' },
      ...baseLabelAttrs
    },
    ports: defaultPorts()
  },
  true
)

Graph.registerNode(
  'basic-text',
  {
    inherit: 'rect',
    width: 100,
    height: 40,
    attrs: {
      body: { stroke: 'transparent', fill: 'transparent' },
      text: { fontSize: 14, fill: '#1f2329' }
    },
    ports: defaultPorts()
  },
  true
)

// 图片节点：支持四角缩放、旋转、拖动与四向连线
Graph.registerNode(
  'basic-image',
  {
    inherit: 'image',
    width: 160,
    height: 120,
    attrs: {
      image: {
        'xlink:href': '',
        preserveAspectRatio: 'none'
      }
    },
    ports: defaultPorts()
  },
  true
)

// ---- 基础图形（多边形） ----
const basicPolygon = (name: string, refPoints: string, w = 100, h = 80) =>
  Graph.registerNode(
    name,
    {
      inherit: 'polygon',
      width: w,
      height: h,
      attrs: { body: { ...basicBody, refPoints }, ...baseLabelAttrs },
      ports: defaultPorts()
    },
    true
  )

basicPolygon('basic-trapezoid', '20,0 80,0 100,100 0,100')
basicPolygon('basic-pentagon', '50,0 100,38 82,100 18,100 0,38')
basicPolygon('basic-hexagon', '25,0 75,0 100,50 75,100 25,100 0,50')
basicPolygon('basic-octagon', '30,0 70,0 100,30 100,70 70,100 30,100 0,70 0,30')
basicPolygon('basic-star', '50,0 61,35 98,35 68,57 79,92 50,70 21,92 32,57 2,35 39,35', 90, 86)
basicPolygon('basic-cross', '35,0 65,0 65,35 100,35 100,65 65,65 65,100 35,100 35,65 0,65 0,35 35,35', 80, 80)
basicPolygon('basic-arrow-right', '0,30 60,30 60,10 100,50 60,90 60,70 0,70', 110, 70)
basicPolygon('basic-arrow-left', '100,30 40,30 40,10 0,50 40,90 40,70 100,70', 110, 70)
basicPolygon('basic-arrow-double', '0,50 20,20 20,40 80,40 80,20 100,50 80,80 80,60 20,60 20,80', 120, 60)

// ---- 基础图形（路径） ----
const basicPath = (name: string, refD: string, w = 100, h = 80) =>
  Graph.registerNode(
    name,
    {
      inherit: 'path',
      width: w,
      height: h,
      attrs: { body: { ...basicBody, refD }, ...baseLabelAttrs },
      ports: defaultPorts()
    },
    true
  )

basicPath(
  'basic-cylinder',
  'M 0 12 C 0 5 100 5 100 12 L 100 88 C 100 95 0 95 0 88 Z M 0 12 C 0 19 100 19 100 12',
  90,
  80
)
basicPath(
  'basic-callout',
  'M 8 0 L 92 0 C 100 0 100 8 100 8 L 100 60 C 100 68 92 68 92 68 L 42 68 L 18 100 L 26 68 L 8 68 C 0 68 0 60 0 60 L 0 8 C 0 0 8 0 8 0 Z',
  120,
  80
)

// ============ 流程图（扩充） ============
const flowBlue = { stroke: '#3370ff', strokeWidth: 1.5, fill: '#eef3ff' }

const flowPolygon = (name: string, refPoints: string, w = 120, h = 60) =>
  Graph.registerNode(
    name,
    {
      inherit: 'polygon',
      width: w,
      height: h,
      attrs: { body: { ...flowBlue, refPoints }, ...baseLabelAttrs },
      ports: defaultPorts()
    },
    true
  )

const flowPath = (name: string, refD: string, w = 120, h = 60) =>
  Graph.registerNode(
    name,
    {
      inherit: 'path',
      width: w,
      height: h,
      attrs: { body: { ...flowBlue, refD }, ...baseLabelAttrs },
      ports: defaultPorts()
    },
    true
  )

// 连接点（小圆）
Graph.registerNode(
  'flow-connector',
  {
    inherit: 'ellipse',
    width: 48,
    height: 48,
    attrs: { body: { ...flowBlue }, ...baseLabelAttrs },
    ports: defaultPorts()
  },
  true
)

// 数据库（圆柱）
flowPath(
  'flow-database',
  'M 0 12 C 0 5 100 5 100 12 L 100 88 C 100 95 0 95 0 88 Z M 0 12 C 0 19 100 19 100 12',
  90,
  64
)

// 显示
flowPath('flow-display', 'M 20 0 L 85 0 C 100 0 100 100 85 100 L 20 100 L 0 50 Z')

// 手动输入
flowPath('flow-manual-input', 'M 0 22 L 100 0 L 100 100 L 0 100 Z')

// 手动操作（倒梯形）
flowPolygon('flow-manual-operation', '0,0 100,0 80,100 20,100')

// 卡片
flowPath('flow-card', 'M 22 0 L 100 0 L 100 100 L 0 100 L 0 22 Z')

// 预定义流程（子程序）
flowPath('flow-predefined', 'M 0 0 L 100 0 L 100 100 L 0 100 Z M 10 0 L 10 100 M 90 0 L 90 100')

// 延迟
flowPath('flow-delay', 'M 0 0 L 55 0 C 100 0 100 100 55 100 L 0 100 Z')

// 页外连接
flowPolygon('flow-offpage', '0,0 100,0 100,62 50,100 0,62')

// 存储数据
flowPath('flow-stored-data', 'M 16 0 L 100 0 C 86 20 86 80 100 100 L 16 100 C 2 80 2 20 16 0 Z')

// 内部存储
flowPath('flow-internal-storage', 'M 0 0 L 100 0 L 100 100 L 0 100 Z M 0 22 L 100 22 M 22 0 L 22 100')

// ============ 连线类型 ============
const baseLine = {
  stroke: '#4e5969',
  strokeWidth: 1.5
}

// 折线（默认流程连线）
Graph.registerEdge(
  'flow-edge',
  {
    inherit: 'edge',
    router: { name: 'manhattan' },
    connector: { name: 'rounded', args: { radius: 8 } },
    attrs: {
      line: {
        ...baseLine,
        targetMarker: { name: 'block', width: 10, height: 8 }
      }
    },
    zIndex: 0
  },
  true
)

// 直线（无箭头）
Graph.registerEdge(
  'line-straight',
  {
    inherit: 'edge',
    router: { name: 'normal' },
    connector: { name: 'normal' },
    attrs: { line: { ...baseLine, targetMarker: null } },
    zIndex: 0
  },
  true
)

// 直线单向箭头
Graph.registerEdge(
  'line-arrow',
  {
    inherit: 'edge',
    router: { name: 'normal' },
    connector: { name: 'normal' },
    attrs: {
      line: { ...baseLine, targetMarker: { name: 'block', width: 10, height: 8 } }
    },
    zIndex: 0
  },
  true
)

// 直线双向箭头
Graph.registerEdge(
  'line-double-arrow',
  {
    inherit: 'edge',
    router: { name: 'normal' },
    connector: { name: 'normal' },
    attrs: {
      line: {
        ...baseLine,
        sourceMarker: { name: 'block', width: 10, height: 8 },
        targetMarker: { name: 'block', width: 10, height: 8 }
      }
    },
    zIndex: 0
  },
  true
)

// 曲线（平滑箭头）
Graph.registerEdge(
  'line-curve',
  {
    inherit: 'edge',
    router: { name: 'normal' },
    connector: { name: 'smooth' },
    attrs: {
      line: { ...baseLine, targetMarker: { name: 'block', width: 10, height: 8 } }
    },
    zIndex: 0
  },
  true
)

export { Shape }
