// 左侧图形面板配置：分为「基础 / 直线 / 流程图」三大类。
// kind: 'node' 通过拖拽创建节点；'edge' 点击在画布中央插入一条连线；'image' 触发图片上传。
// icon: 面板中展示的 SVG 预览（viewBox 44x30）。
import type { ShapeCategory } from './types'

const S = { fill: '#fff', stroke: '#4e5969', sw: 1.4 }

export const SHAPE_CATEGORIES: ShapeCategory[] = [
  {
    key: 'basic',
    title: '基础',
    items: [
      {
        key: 'rect',
        kind: 'node',
        name: '矩形',
        shape: 'basic-rect',
        label: '',
        icon: `<rect x="6" y="7" width="32" height="16" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'round',
        kind: 'node',
        name: '圆角矩形',
        shape: 'basic-round',
        label: '',
        icon: `<rect x="6" y="7" width="32" height="16" rx="5" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'ellipse',
        kind: 'node',
        name: '椭圆',
        shape: 'basic-ellipse',
        label: '',
        icon: `<ellipse cx="22" cy="15" rx="16" ry="9" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'circle',
        kind: 'node',
        name: '圆形',
        shape: 'basic-circle',
        label: '',
        icon: `<circle cx="22" cy="15" r="9" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'diamond',
        kind: 'node',
        name: '菱形',
        shape: 'basic-diamond',
        label: '',
        icon: `<polygon points="22,5 38,15 22,25 6,15" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'parallelogram',
        kind: 'node',
        name: '平行四边形',
        shape: 'basic-parallelogram',
        label: '',
        icon: `<polygon points="12,7 38,7 32,23 6,23" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'triangle',
        kind: 'node',
        name: '三角形',
        shape: 'basic-triangle',
        label: '',
        icon: `<polygon points="22,6 36,24 8,24" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'trapezoid',
        kind: 'node',
        name: '梯形',
        shape: 'basic-trapezoid',
        label: '',
        icon: `<polygon points="14,7 30,7 38,23 6,23" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'pentagon',
        kind: 'node',
        name: '五边形',
        shape: 'basic-pentagon',
        label: '',
        icon: `<polygon points="22,5 39,16 32,26 12,26 5,16" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'hexagon',
        kind: 'node',
        name: '六边形',
        shape: 'basic-hexagon',
        label: '',
        icon: `<polygon points="13,6 31,6 39,15 31,24 13,24 5,15" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'octagon',
        kind: 'node',
        name: '八边形',
        shape: 'basic-octagon',
        label: '',
        icon: `<polygon points="15,6 29,6 38,12 38,18 29,24 15,24 6,18 6,12" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'star',
        kind: 'node',
        name: '星形',
        shape: 'basic-star',
        label: '',
        icon: `<polygon points="22,4 26,13 36,13 28,19 31,28 22,22 13,28 16,19 8,13 18,13" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'cross',
        kind: 'node',
        name: '十字',
        shape: 'basic-cross',
        label: '',
        icon: `<polygon points="18,6 26,6 26,12 32,12 32,18 26,18 26,24 18,24 18,18 12,18 12,12 18,12" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'arrow-right',
        kind: 'node',
        name: '右箭头',
        shape: 'basic-arrow-right',
        label: '',
        icon: `<polygon points="6,12 26,12 26,7 38,15 26,23 26,18 6,18" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'arrow-left',
        kind: 'node',
        name: '左箭头',
        shape: 'basic-arrow-left',
        label: '',
        icon: `<polygon points="38,12 18,12 18,7 6,15 18,23 18,18 38,18" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'arrow-double',
        kind: 'node',
        name: '双向箭头',
        shape: 'basic-arrow-double',
        label: '',
        icon: `<polygon points="4,15 12,9 12,13 32,13 32,9 40,15 32,21 32,17 12,17 12,21" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'cylinder',
        kind: 'node',
        name: '圆柱',
        shape: 'basic-cylinder',
        label: '',
        icon: `<path d="M9,9 C9,6 35,6 35,9 L35,22 C35,25 9,25 9,22 Z M9,9 C9,12 35,12 35,9" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'callout',
        kind: 'node',
        name: '标注',
        shape: 'basic-callout',
        label: '',
        icon: `<path d="M7,6 L37,6 L37,19 L18,19 L12,25 L14,19 L7,19 Z" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'text',
        kind: 'node',
        name: '文本',
        shape: 'basic-text',
        label: '文本',
        icon: `<text x="22" y="20" font-size="15" fill="${S.stroke}" text-anchor="middle" font-family="sans-serif">A</text>`
      },
      {
        key: 'image',
        kind: 'image',
        name: '图片',
        icon: `<rect x="6" y="7" width="32" height="16" rx="2" fill="${S.fill}" stroke="${S.stroke}" stroke-width="${S.sw}"/><circle cx="14" cy="13" r="2.4" fill="${S.stroke}"/><path d="M8,21 L17,14 L23,19 L28,15 L36,21 Z" fill="${S.stroke}"/>`
      }
    ]
  },
  {
    key: 'line',
    title: '直线',
    items: [
      {
        key: 'straight',
        kind: 'edge',
        name: '直线',
        shape: 'line-straight',
        icon: `<line x1="6" y1="15" x2="38" y2="15" stroke="${S.stroke}" stroke-width="${S.sw}"/>`
      },
      {
        key: 'arrow',
        kind: 'edge',
        name: '箭头',
        shape: 'line-arrow',
        icon: `<line x1="6" y1="15" x2="34" y2="15" stroke="${S.stroke}" stroke-width="${S.sw}"/><polygon points="34,11 40,15 34,19" fill="${S.stroke}"/>`
      },
      {
        key: 'double-arrow',
        kind: 'edge',
        name: '双向箭头',
        shape: 'line-double-arrow',
        icon: `<line x1="10" y1="15" x2="34" y2="15" stroke="${S.stroke}" stroke-width="${S.sw}"/><polygon points="10,11 4,15 10,19" fill="${S.stroke}"/><polygon points="34,11 40,15 34,19" fill="${S.stroke}"/>`
      },
      {
        key: 'polyline',
        kind: 'edge',
        name: '折线',
        shape: 'flow-edge',
        icon: `<polyline points="6,8 22,8 22,22 34,22" fill="none" stroke="${S.stroke}" stroke-width="${S.sw}"/><polygon points="34,18 40,22 34,26" fill="${S.stroke}"/>`
      },
      {
        key: 'curve',
        kind: 'edge',
        name: '曲线',
        shape: 'line-curve',
        icon: `<path d="M6,22 C16,22 24,8 34,8" fill="none" stroke="${S.stroke}" stroke-width="${S.sw}"/><polygon points="32,4 40,8 32,12" fill="${S.stroke}"/>`
      }
    ]
  },
  {
    key: 'flow',
    title: '流程图',
    items: [
      {
        key: 'terminal',
        kind: 'node',
        name: '开始/结束',
        shape: 'flow-terminal',
        label: '开始',
        icon: `<rect x="5" y="8" width="34" height="14" rx="7" fill="#e6fffb" stroke="#00c6a7" stroke-width="${S.sw}"/>`
      },
      {
        key: 'process',
        kind: 'node',
        name: '处理',
        shape: 'flow-process',
        label: '处理步骤',
        icon: `<rect x="5" y="8" width="34" height="14" rx="3" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'decision',
        kind: 'node',
        name: '判断',
        shape: 'flow-decision',
        label: '是否满足?',
        icon: `<polygon points="22,5 38,15 22,25 6,15" fill="#fff7e6" stroke="#ff8f1f" stroke-width="${S.sw}"/>`
      },
      {
        key: 'data',
        kind: 'node',
        name: '数据',
        shape: 'flow-data',
        label: '数据',
        icon: `<polygon points="12,8 38,8 32,22 6,22" fill="#f4edff" stroke="#8f5eff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'document',
        kind: 'node',
        name: '文档',
        shape: 'flow-document',
        label: '文档',
        icon: `<path d="M6,8 L38,8 L38,20 C31,16 29,24 22,20 C16,17 13,19 6,21 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'preparation',
        kind: 'node',
        name: '准备',
        shape: 'flow-preparation',
        label: '准备',
        icon: `<polygon points="13,8 31,8 39,15 31,22 13,22 5,15" fill="#e6fffb" stroke="#00c6a7" stroke-width="${S.sw}"/>`
      },
      {
        key: 'connector',
        kind: 'node',
        name: '连接点',
        shape: 'flow-connector',
        label: '',
        icon: `<circle cx="22" cy="15" r="8" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'database',
        kind: 'node',
        name: '数据库',
        shape: 'flow-database',
        label: '数据库',
        icon: `<path d="M9,9 C9,6 35,6 35,9 L35,22 C35,25 9,25 9,22 Z M9,9 C9,12 35,12 35,9" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'display',
        kind: 'node',
        name: '显示',
        shape: 'flow-display',
        label: '显示',
        icon: `<path d="M13,6 L34,6 C40,6 40,24 34,24 L13,24 L6,15 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'manual-input',
        kind: 'node',
        name: '手动输入',
        shape: 'flow-manual-input',
        label: '手动输入',
        icon: `<path d="M6,11 L38,6 L38,24 L6,24 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'manual-operation',
        kind: 'node',
        name: '手动操作',
        shape: 'flow-manual-operation',
        label: '手动操作',
        icon: `<polygon points="6,7 38,7 32,23 12,23" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'card',
        kind: 'node',
        name: '卡片',
        shape: 'flow-card',
        label: '卡片',
        icon: `<path d="M12,6 L38,6 L38,24 L6,24 L6,12 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'predefined',
        kind: 'node',
        name: '预定义流程',
        shape: 'flow-predefined',
        label: '子流程',
        icon: `<rect x="6" y="7" width="32" height="16" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/><line x1="11" y1="7" x2="11" y2="23" stroke="#3370ff" stroke-width="${S.sw}"/><line x1="33" y1="7" x2="33" y2="23" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'delay',
        kind: 'node',
        name: '延迟',
        shape: 'flow-delay',
        label: '延迟',
        icon: `<path d="M6,7 L26,7 C38,7 38,23 26,23 L6,23 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'offpage',
        kind: 'node',
        name: '页外连接',
        shape: 'flow-offpage',
        label: '',
        icon: `<polygon points="6,6 38,6 38,17 22,25 6,17" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'stored-data',
        kind: 'node',
        name: '存储数据',
        shape: 'flow-stored-data',
        label: '存储',
        icon: `<path d="M12,6 L38,6 C33,11 33,19 38,24 L12,24 C7,19 7,11 12,6 Z" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/>`
      },
      {
        key: 'internal-storage',
        kind: 'node',
        name: '内部存储',
        shape: 'flow-internal-storage',
        label: '',
        icon: `<rect x="6" y="7" width="32" height="16" fill="#eef3ff" stroke="#3370ff" stroke-width="${S.sw}"/><line x1="6" y1="12" x2="38" y2="12" stroke="#3370ff" stroke-width="${S.sw}"/><line x1="12" y1="7" x2="12" y2="23" stroke="#3370ff" stroke-width="${S.sw}"/>`
      }
    ]
  }
]
