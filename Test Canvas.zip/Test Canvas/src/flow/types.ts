// 全局共享类型定义
import type { Graph } from '@antv/x6'

/** 画布序列化数据（X6 graph.toJSON 结果），作为 v-model 的值类型 */
export type GraphData = ReturnType<Graph['toJSON']>

/** 左侧图形面板项的交互种类 */
export type ShapeKind = 'node' | 'edge' | 'image'

/** 左侧图形面板中的一个图形项 */
export interface ShapeItem {
  key: string
  kind: ShapeKind
  name: string
  /** 注册在 shapes.ts 中的 shape 名称（image 项可省略） */
  shape?: string
  /** 节点默认文本 */
  label?: string
  /** 面板预览用的 SVG 字符串（viewBox 44x30） */
  icon: string
}

/** 左侧图形面板的分类 */
export interface ShapeCategory {
  key: string
  title: string
  items: ShapeItem[]
}

/** 右键菜单项 */
export interface MenuItem {
  label?: string
  action?: string
  shortcut?: string
  danger?: boolean
  disabled?: boolean
  divider?: boolean
}

/** 右键菜单的目标类型 */
export type MenuTargetType = 'cell' | 'blank'

/** 工具栏 / 右键菜单可派发的动作名 */
export type FlowAction =
  | 'undo'
  | 'redo'
  | 'zoomIn'
  | 'zoomOut'
  | 'fit'
  | 'reset'
  | 'copy'
  | 'paste'
  | 'delete'
  | 'selectAll'
  | 'toFront'
  | 'toBack'
  | 'clear'
  | 'save'
  | 'export'

/** 画板模式：编辑 / 预览缩略 */
export type BoardMode = 'edit' | 'preview'
