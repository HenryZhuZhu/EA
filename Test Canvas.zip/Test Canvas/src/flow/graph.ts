import { Graph, type Edge } from '@antv/x6'
import { Snapline } from '@antv/x6-plugin-snapline'
import { Selection } from '@antv/x6-plugin-selection'
import { Keyboard } from '@antv/x6-plugin-keyboard'
import { Clipboard } from '@antv/x6-plugin-clipboard'
import { History } from '@antv/x6-plugin-history'
import { Transform } from '@antv/x6-plugin-transform'
import { MiniMap } from '@antv/x6-plugin-minimap'
import './shapes'

export const STORAGE_KEY = 'feishu-flow-board-data'

/**
 * 创建并配置画布，装配飞书流程图所需的全部交互插件。
 * @param container 画布容器
 * @param minimapContainer 缩略图容器
 */
export function createGraph(container: HTMLElement, minimapContainer?: HTMLElement | null): Graph {
  const graph: Graph = new Graph({
    container,
    autoResize: true,
    background: { color: '#f5f6f7' },
    grid: {
      size: 10,
      visible: true,
      type: 'dot',
      args: { color: '#dcdfe6', thickness: 1 }
    },
    panning: { enabled: true, eventTypes: ['mouseWheel'] },
    mousewheel: {
      enabled: true,
      modifiers: ['ctrl', 'meta'],
      minScale: 0.3,
      maxScale: 3
    },
    connecting: {
      snap: { radius: 20 },
      allowBlank: true,
      allowLoop: false,
      allowNode: false,
      allowMulti: true,
      highlight: true,
      connector: { name: 'rounded', args: { radius: 8 } },
      router: { name: 'manhattan' },
      createEdge(): Edge {
        return graph.createEdge({ shape: 'flow-edge' })
      },
      validateConnection({ targetMagnet, targetView }) {
        // 拖到空白处允许（自由端点，可伸缩/旋转）；连到节点则必须落在连接桩上
        if (!targetView) return true
        return !!targetMagnet
      }
    },
    highlighting: {
      magnetAdsorbed: {
        name: 'stroke',
        args: {
          attrs: { fill: '#fff', stroke: '#3370ff', strokeWidth: 2 }
        }
      }
    }
  })

  graph
    .use(new Snapline({ enabled: true, sharp: true }))
    .use(
      new Selection({
        enabled: true,
        multiple: true,
        rubberband: true,
        movable: true,
        showNodeSelectionBox: true
      })
    )
    .use(new Keyboard({ enabled: true }))
    .use(new Clipboard({ enabled: true }))
    .use(new History({ enabled: true }))
    .use(
      new Transform({
        resizing: { enabled: true, minWidth: 40, minHeight: 24, preserveAspectRatio: false },
        rotating: { enabled: true, grid: 15 }
      })
    )

  if (minimapContainer) {
    graph.use(
      new MiniMap({
        container: minimapContainer,
        width: 200,
        height: 130,
        padding: 10
      })
    )
  }

  bindPortVisibility(graph)
  bindKeyboardShortcuts(graph)

  return graph
}

/**
 * 创建只读预览画布：不含任何交互插件，用于保存后的缩略展示。
 */
export function createPreviewGraph(container: HTMLElement): Graph {
  return new Graph({
    container,
    autoResize: true,
    interacting: false,
    background: { color: '#ffffff' },
    grid: { visible: false }
  })
}

// 鼠标悬停节点时显示连接桩
function bindPortVisibility(graph: Graph) {
  const setPortsVisible = (show: boolean) => {
    const ports = graph.container.querySelectorAll<HTMLElement>('.x6-port-body')
    ports.forEach((port) => {
      port.style.visibility = show ? 'visible' : 'hidden'
    })
  }

  graph.on('node:mouseenter', () => setPortsVisible(true))
  graph.on('node:mouseleave', () => setPortsVisible(false))
}

// 键盘快捷键：复制 / 粘贴 / 删除 / 撤销 / 重做 / 全选
function bindKeyboardShortcuts(graph: Graph) {
  graph.bindKey(['meta+c', 'ctrl+c'], () => {
    const cells = graph.getSelectedCells()
    if (cells.length) graph.copy(cells)
    return false
  })

  graph.bindKey(['meta+v', 'ctrl+v'], () => {
    if (!graph.isClipboardEmpty()) {
      const cells = graph.paste({ offset: 32 })
      graph.cleanSelection()
      graph.select(cells)
    }
    return false
  })

  graph.bindKey(['meta+z', 'ctrl+z'], () => {
    if (graph.canUndo()) graph.undo()
    return false
  })

  graph.bindKey(['meta+shift+z', 'ctrl+shift+z', 'ctrl+y'], () => {
    if (graph.canRedo()) graph.redo()
    return false
  })

  graph.bindKey(['backspace', 'delete'], () => {
    const cells = graph.getSelectedCells()
    if (cells.length) graph.removeCells(cells)
    return false
  })

  graph.bindKey(['meta+a', 'ctrl+a'], () => {
    graph.select(graph.getCells())
    return false
  })
}

/** 保存画布数据到 localStorage */
export function saveGraph(graph: Graph) {
  const data = graph.toJSON()
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  return data
}

/** 从 localStorage 载入画布数据，成功返回 true */
export function loadGraph(graph: Graph): boolean {
  const raw = localStorage.getItem(STORAGE_KEY)
  if (!raw) return false
  try {
    graph.fromJSON(JSON.parse(raw))
    return true
  } catch (e) {
    console.error('载入画布数据失败：', e)
    return false
  }
}

/** 读取已保存的画布 JSON（无则返回 null） */
export function readSavedGraph(): Record<string, unknown> | null {
  const raw = localStorage.getItem(STORAGE_KEY)
  if (!raw) return null
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}
