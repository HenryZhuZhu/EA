<template>
  <FlowDiagram v-model="diagramData" />
</template>

<script setup lang="ts">
import { ref, watch } from 'vue'
import FlowDiagram from './components/FlowDiagram.vue'
import { STORAGE_KEY, readSavedGraph } from './flow/graph'
import type { GraphData } from './flow/types'

// 初始渲染数据来自“数据库”（此处以 localStorage 演示）
const diagramData = ref<GraphData | null>(readSavedGraph() as GraphData | null)

// v-model 实时变化 -> 存入“数据库”，作为下次初始化渲染的数据
watch(diagramData, (val) => {
  if (val) localStorage.setItem(STORAGE_KEY, JSON.stringify(val))
})
</script>
