<template>
  <div
    v-if="visible"
    class="context-menu"
    :style="{ left: x + 'px', top: y + 'px' }"
    @contextmenu.prevent
  >
    <template v-for="(item, i) in items" :key="i">
      <div v-if="item.divider" class="cm-divider"></div>
      <div
        v-else
        class="cm-item"
        :class="{ disabled: item.disabled, danger: item.danger }"
        @click="onClick(item)"
      >
        <span>{{ item.label }}</span>
        <span v-if="item.shortcut" class="cm-shortcut">{{ item.shortcut }}</span>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import type { FlowAction, MenuItem } from '../flow/types'

withDefaults(
  defineProps<{
    visible?: boolean
    x?: number
    y?: number
    items?: MenuItem[]
  }>(),
  {
    visible: false,
    x: 0,
    y: 0,
    items: () => []
  }
)
const emit = defineEmits<{ (e: 'select', action: FlowAction): void }>()

function onClick(item: MenuItem) {
  if (item.disabled || !item.action) return
  emit('select', item.action as FlowAction)
}
</script>

<style scoped>
.context-menu {
  position: fixed;
  min-width: 160px;
  background: #fff;
  border: 1px solid #e5e6eb;
  border-radius: 8px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.12);
  padding: 4px;
  z-index: 100;
  user-select: none;
}

.cm-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 32px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  color: #1f2329;
  cursor: pointer;
}

.cm-item:hover {
  background: #f2f3f5;
}

.cm-item.danger:hover {
  background: #fef0f0;
  color: #f53f3f;
}

.cm-item.disabled {
  color: #c9cdd4;
  cursor: not-allowed;
}

.cm-shortcut {
  font-size: 12px;
  color: #a9aeb8;
  margin-left: 24px;
}

.cm-divider {
  height: 1px;
  background: #f2f3f5;
  margin: 4px 6px;
}
</style>
