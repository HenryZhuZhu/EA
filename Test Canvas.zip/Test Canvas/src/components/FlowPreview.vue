<template>
  <div class="flow-preview">
    <div class="preview-card" @dblclick="emit('edit')">
      <div class="preview-head">
        <div class="preview-title">
          <span class="preview-dot"></span>
          流程图
        </div>
        <button class="edit-btn" @click="emit('edit')">编辑</button>
      </div>
      <div class="preview-body">
        <div ref="previewEl" class="preview-canvas"></div>
        <div v-if="empty" class="preview-empty">暂无流程图内容，点击「编辑」开始绘制</div>
      </div>
      <div class="preview-foot">双击缩略图可进入编辑</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import type { Graph } from '@antv/x6'
import { createPreviewGraph } from '../flow/graph'
import type { GraphData } from '../flow/types'

const props = defineProps<{ data?: GraphData | null }>()
const emit = defineEmits<{ (e: 'edit'): void }>()

const previewEl = ref<HTMLElement | null>(null)
const empty = ref(false)
let graph: Graph | null = null

onMounted(() => {
  const data = props.data
  const cells = (data?.cells as unknown[]) || []
  if (!previewEl.value || cells.length === 0) {
    empty.value = true
    return
  }
  graph = createPreviewGraph(previewEl.value)
  graph.fromJSON(data as never)
  // 等待渲染完成后适应画布
  requestAnimationFrame(() => {
    graph?.zoomToFit({ padding: 24, maxScale: 1 })
  })
})

onBeforeUnmount(() => {
  graph?.dispose()
  graph = null
})
</script>

<style scoped>
.flow-preview {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 32px;
  background: #f5f6f7;
}

.preview-card {
  width: min(760px, 92%);
  height: min(520px, 88%);
  background: #fff;
  border: 1px solid #e5e6eb;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  cursor: pointer;
  transition: box-shadow 0.15s ease, border-color 0.15s ease;
}

.preview-card:hover {
  border-color: #3370ff;
  box-shadow: 0 10px 40px rgba(51, 112, 255, 0.18);
}

.preview-head {
  height: 48px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  border-bottom: 1px solid #f2f3f5;
}

.preview-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  font-weight: 600;
  color: #1f2329;
}

.preview-dot {
  width: 10px;
  height: 10px;
  border-radius: 3px;
  background: linear-gradient(135deg, #3370ff, #00c6a7);
}

.edit-btn {
  height: 30px;
  padding: 0 16px;
  border: 1px solid #e5e6eb;
  border-radius: 6px;
  background: #fff;
  color: #3370ff;
  font-size: 13px;
  font-weight: 500;
  transition: all 0.15s ease;
}

.edit-btn:hover {
  border-color: #3370ff;
  background: #eef3ff;
}

.preview-body {
  position: relative;
  flex: 1;
  min-height: 0;
  background:
    linear-gradient(#f7f8fa 0 0) padding-box;
}

.preview-canvas {
  width: 100%;
  height: 100%;
}

.preview-empty {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #c9cdd4;
  font-size: 14px;
}

.preview-foot {
  height: 34px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-size: 12px;
  color: #a9aeb8;
  border-top: 1px solid #f2f3f5;
}
</style>
