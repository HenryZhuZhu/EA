<template>
  <div class="flow-board">
    <BoardHeader :zoom="zoom" @action="onAction" />
    <div class="board-body">
      <BoardStencil
        :dnd="dnd"
        :graph="graph"
        @text-mode="enterTextMode"
        @upload-image="uploadImage"
      />
      <BoardCanvas
        :is-empty="isEmpty"
        :text-mode="textMode"
        :selected-cells="selectedCells"
        :menu="menu"
        :menu-items="menuItems"
        @ready="initGraph"
        @dispose="disposeGraph"
        @menu-select="onMenuSelect"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { watch } from 'vue'
import BoardHeader from './board/BoardHeader.vue'
import BoardStencil from './board/BoardStencil.vue'
import BoardCanvas from './board/BoardCanvas.vue'
import { useFlowBoard } from '../composables/useFlowBoard'
import type { GraphData } from '../flow/types'

const props = defineProps<{ data?: GraphData | null }>()
const emit = defineEmits<{
  (e: 'save'): void
  (e: 'change', data: GraphData): void
}>()

const {
  graph,
  dnd,
  zoom,
  isEmpty,
  selectedCells,
  textMode,
  menu,
  menuItems,
  initGraph,
  disposeGraph,
  syncFromModel,
  onAction,
  onMenuSelect,
  enterTextMode,
  uploadImage
} = useFlowBoard({
  getData: () => props.data,
  onChange: (data) => emit('change', data),
  onSaved: () => emit('save')
})

// 外部（v-model）数据变化时写回画布（自身回声会被忽略）
watch(
  () => props.data,
  (val) => syncFromModel(val)
)
</script>

<style scoped>
.flow-board {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.board-body {
  flex: 1;
  display: flex;
  min-height: 0;
}
</style>
