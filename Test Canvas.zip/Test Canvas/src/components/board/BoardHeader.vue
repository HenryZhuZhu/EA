<template>
  <div class="toolbar">
    <div class="toolbar-brand">
      <span class="brand-dot"></span>
      流程画图板
    </div>

    <div class="toolbar-group">
      <button class="tb-btn" title="撤销 (⌘Z)" @click="emit('action', 'undo')">撤销</button>
      <button class="tb-btn" title="重做 (⌘⇧Z)" @click="emit('action', 'redo')">重做</button>
    </div>

    <div class="toolbar-divider"></div>

    <div class="toolbar-group">
      <button class="tb-btn" title="放大" @click="emit('action', 'zoomIn')">＋</button>
      <span class="zoom-value">{{ Math.round(zoom * 100) }}%</span>
      <button class="tb-btn" title="缩小" @click="emit('action', 'zoomOut')">－</button>
      <button class="tb-btn" title="适应画布" @click="emit('action', 'fit')">适应</button>
      <button class="tb-btn" title="实际大小" @click="emit('action', 'reset')">1:1</button>
    </div>

    <div class="toolbar-divider"></div>

    <div class="toolbar-group">
      <button class="tb-btn" title="复制 (⌘C)" @click="emit('action', 'copy')">复制</button>
      <button class="tb-btn" title="粘贴 (⌘V)" @click="emit('action', 'paste')">粘贴</button>
      <button class="tb-btn danger" title="删除 (Delete)" @click="emit('action', 'delete')">删除</button>
    </div>

    <div class="toolbar-spacer"></div>

    <div class="toolbar-group">
      <button class="tb-btn ghost" @click="emit('action', 'clear')">清空</button>
      <button class="tb-btn ghost" @click="emit('action', 'export')">导出 JSON</button>
      <button class="tb-btn primary" @click="emit('action', 'save')">保存</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { FlowAction } from '../../flow/types'

withDefaults(defineProps<{ zoom?: number }>(), { zoom: 1 })
const emit = defineEmits<{ (e: 'action', action: FlowAction): void }>()
</script>

<style scoped>
.toolbar {
  height: 52px;
  background: #fff;
  border-bottom: 1px solid #e5e6eb;
  display: flex;
  align-items: center;
  padding: 0 16px;
  gap: 8px;
}

.toolbar-brand {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 600;
  color: #1f2329;
  margin-right: 8px;
}

.brand-dot {
  width: 10px;
  height: 10px;
  border-radius: 3px;
  background: linear-gradient(135deg, #3370ff, #00c6a7);
}

.toolbar-group {
  display: flex;
  align-items: center;
  gap: 4px;
}

.toolbar-divider {
  width: 1px;
  height: 22px;
  background: #e5e6eb;
  margin: 0 6px;
}

.toolbar-spacer {
  flex: 1;
}

.tb-btn {
  height: 32px;
  min-width: 32px;
  padding: 0 10px;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  color: #4e5969;
  font-size: 13px;
  transition: all 0.15s ease;
}

.tb-btn:hover {
  background: #f2f3f5;
  color: #1f2329;
}

.tb-btn.primary {
  background: #3370ff;
  color: #fff;
}

.tb-btn.primary:hover {
  background: #2860e0;
}

.tb-btn.ghost {
  border-color: #e5e6eb;
}

.tb-btn.danger:hover {
  background: #fef0f0;
  color: #f53f3f;
}

.zoom-value {
  font-size: 12px;
  color: #86909c;
  min-width: 40px;
  text-align: center;
}
</style>
