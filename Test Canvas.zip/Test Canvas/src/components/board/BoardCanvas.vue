<template>
  <div class="canvas-wrap" :class="{ 'text-mode': textMode }" @contextmenu.prevent>
    <div ref="canvasEl" class="canvas"></div>
    <div ref="minimapEl" class="minimap"></div>
    <div v-if="isEmpty" class="canvas-empty">从左侧拖入节点开始绘制流程图</div>
    <FormatPanel :cells="selectedCells" />
    <ContextMenu
      :visible="menu.visible"
      :x="menu.x"
      :y="menu.y"
      :items="menuItems"
      @select="(action) => emit('menu-select', action)"
    />
  </div>
</template>

<script setup lang="ts">
import { onBeforeUnmount, onMounted, ref } from 'vue'
import type { Cell } from '@antv/x6'
import FormatPanel from '../FormatPanel.vue'
import ContextMenu from '../ContextMenu.vue'
import type { FlowAction, MenuItem } from '../../flow/types'

defineProps<{
  isEmpty: boolean
  textMode: boolean
  selectedCells: Cell[]
  menu: { visible: boolean; x: number; y: number }
  menuItems: MenuItem[]
}>()

const emit = defineEmits<{
  (e: 'ready', canvas: HTMLElement, minimap: HTMLElement | null): void
  (e: 'dispose'): void
  (e: 'menu-select', action: FlowAction): void
}>()

const canvasEl = ref<HTMLElement | null>(null)
const minimapEl = ref<HTMLElement | null>(null)

onMounted(() => {
  if (canvasEl.value) emit('ready', canvasEl.value, minimapEl.value)
})

onBeforeUnmount(() => emit('dispose'))
</script>

<style scoped>
.canvas-wrap {
  position: relative;
  flex: 1;
  min-width: 0;
  height: 100%;
}

.canvas {
  width: 100%;
  height: 100%;
}

.canvas-wrap.text-mode {
  cursor: text;
}

.minimap {
  position: absolute;
  right: 16px;
  bottom: 16px;
  border: 1px solid #e5e6eb;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  background: #fff;
}

.canvas-empty {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #c9cdd4;
  font-size: 15px;
  pointer-events: none;
}
</style>
