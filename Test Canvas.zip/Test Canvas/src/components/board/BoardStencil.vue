<template>
  <div class="stencil-panel">
    <div class="stencil-header">图形</div>
    <div class="stencil-scroll">
      <div v-for="cat in categories" :key="cat.key" class="stencil-group">
        <div class="group-title" @click="toggle(cat.key)">
          <span class="group-arrow" :class="{ collapsed: collapsed[cat.key] }">▾</span>
          {{ cat.title }}
        </div>
        <div v-show="!collapsed[cat.key]" class="group-grid">
          <div
            v-for="item in cat.items"
            :key="item.key"
            class="shape-tile"
            :class="{ 'is-image': item.kind === 'image' }"
            :title="item.name"
            @mousedown="(e) => onTileMouseDown(e, item)"
          >
            <svg class="shape-icon" viewBox="0 0 44 30" v-html="item.icon"></svg>
            <span class="shape-name">{{ item.name }}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="stencil-tip">拖拽图形到画布 · 悬停节点边缘可连线</div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from 'vue'
import type { Dnd } from '@antv/x6-plugin-dnd'
import type { Graph } from '@antv/x6'
import { SHAPE_CATEGORIES } from '../../flow/nodeTemplates'
import type { ShapeItem } from '../../flow/types'

const props = defineProps<{
  dnd?: Dnd | null
  graph?: Graph | null
}>()
const emit = defineEmits<{
  (e: 'text-mode'): void
  (e: 'upload-image'): void
}>()

const categories = SHAPE_CATEGORIES
const collapsed = reactive<Record<string, boolean>>({})

function toggle(key: string) {
  collapsed[key] = !collapsed[key]
}

function onTileMouseDown(e: MouseEvent, item: ShapeItem) {
  if (item.kind === 'image') return emit('upload-image')
  if (item.kind === 'edge') return startEdgeDrag(e, item)
  if (item.shape === 'basic-text') return startTextTile(e, item)
  startDragNode(e, item)
}

// 拖拽创建节点
function startDragNode(e: MouseEvent, item: ShapeItem) {
  if (!props.dnd || !props.graph) return
  const node = props.graph.createNode({
    shape: item.shape,
    label: item.label || ''
  })
  props.dnd.start(node, e)
}

// 连线：拖到画布落点插入；纯点击则插入到可视区中央
function startEdgeDrag(e: MouseEvent, item: ShapeItem) {
  const startX = e.clientX
  const startY = e.clientY
  let moved = false
  const onMove = (ev: MouseEvent) => {
    if (Math.hypot(ev.clientX - startX, ev.clientY - startY) > 5) moved = true
  }
  const onUp = (ev: MouseEvent) => {
    document.removeEventListener('mousemove', onMove)
    document.removeEventListener('mouseup', onUp)
    insertEdgeAt(item, ev.clientX, ev.clientY, moved)
  }
  document.addEventListener('mousemove', onMove)
  document.addEventListener('mouseup', onUp)
}

function insertEdgeAt(item: ShapeItem, clientX: number, clientY: number, moved: boolean) {
  const g = props.graph
  if (!g) return
  const rect = g.container.getBoundingClientRect()
  const inside =
    clientX >= rect.left && clientX <= rect.right && clientY >= rect.top && clientY <= rect.bottom
  let cx: number
  let cy: number
  if (moved && inside) {
    const p = g.clientToLocal(clientX, clientY)
    cx = p.x
    cy = p.y
  } else {
    const area = g.getGraphArea()
    cx = area.x + area.width / 2
    cy = area.y + area.height / 2
  }
  const edge = g.addEdge({
    shape: item.shape,
    source: { x: cx - 70, y: cy },
    target: { x: cx + 70, y: cy }
  })
  g.cleanSelection()
  g.select(edge)
}

// 文本：拖动=放到落点；点击=进入“文本插入”光标模式
function startTextTile(e: MouseEvent, item: ShapeItem) {
  const startX = e.clientX
  const startY = e.clientY
  let moved = false
  const onMove = (ev: MouseEvent) => {
    if (!moved && Math.hypot(ev.clientX - startX, ev.clientY - startY) > 5) {
      moved = true
      cleanup()
      startDragNode(ev, item)
    }
  }
  const onUp = () => {
    cleanup()
    if (!moved) emit('text-mode')
  }
  function cleanup() {
    document.removeEventListener('mousemove', onMove)
    document.removeEventListener('mouseup', onUp)
  }
  document.addEventListener('mousemove', onMove)
  document.addEventListener('mouseup', onUp)
}
</script>

<style scoped>
.stencil-panel {
  width: 208px;
  height: 100%;
  background: #fff;
  border-right: 1px solid #e5e6eb;
  display: flex;
  flex-direction: column;
}

.stencil-header {
  height: 40px;
  display: flex;
  align-items: center;
  padding: 0 16px;
  font-size: 13px;
  font-weight: 600;
  color: #1f2329;
  border-bottom: 1px solid #f2f3f5;
}

.stencil-scroll {
  flex: 1;
  overflow-y: auto;
  padding: 8px 12px;
}

.stencil-group {
  margin-bottom: 4px;
}

.group-title {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  font-size: 12px;
  font-weight: 600;
  color: #86909c;
  cursor: pointer;
  user-select: none;
}

.group-arrow {
  font-size: 10px;
  transition: transform 0.15s ease;
}

.group-arrow.collapsed {
  transform: rotate(-90deg);
}

.group-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  padding: 4px 0 8px;
}

.shape-tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 8px 4px 6px;
  border: 1px solid #e5e6eb;
  border-radius: 8px;
  background: #fff;
  cursor: grab;
  transition: all 0.15s ease;
  user-select: none;
}

.shape-tile:hover {
  border-color: #3370ff;
  box-shadow: 0 2px 8px rgba(51, 112, 255, 0.15);
}

.shape-tile:active {
  cursor: grabbing;
}

.shape-tile.is-image {
  cursor: pointer;
}

.shape-icon {
  width: 44px;
  height: 30px;
}

.shape-name {
  font-size: 11px;
  color: #4e5969;
  text-align: center;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}

.stencil-tip {
  padding: 10px 16px;
  font-size: 11px;
  color: #a9aeb8;
  line-height: 1.5;
  border-top: 1px solid #f2f3f5;
}
</style>
