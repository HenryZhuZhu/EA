<template>
  <div v-if="cells.length" class="format-panel">
    <div class="fp-title">{{ title }}</div>

    <!-- 填充色（仅节点） -->
    <div v-if="hasNode" class="fp-section">
      <div class="fp-label">填充</div>
      <div class="fp-swatches">
        <button
          class="sw sw-none"
          :class="{ active: current.fill === 'transparent' }"
          title="无填充"
          @click="setFill('transparent')"
        ></button>
        <button
          v-for="c in fillColors"
          :key="c"
          class="sw"
          :class="{ active: current.fill === c }"
          :style="{ background: c }"
          @click="setFill(c)"
        ></button>
      </div>
    </div>

    <!-- 边框 / 线条色 -->
    <div class="fp-section">
      <div class="fp-label">{{ hasNode ? '边框' : '线条' }}</div>
      <div class="fp-swatches">
        <button
          v-for="c in strokeColors"
          :key="c"
          class="sw"
          :class="{ active: current.stroke === c }"
          :style="{ background: c }"
          @click="setStroke(c)"
        ></button>
      </div>
    </div>

    <!-- 文字色（仅节点） -->
    <div v-if="hasNode" class="fp-section">
      <div class="fp-label">文字</div>
      <div class="fp-swatches">
        <button
          v-for="c in textColors"
          :key="c"
          class="sw"
          :class="{ active: current.textFill === c }"
          :style="{ background: c }"
          @click="setTextFill(c)"
        ></button>
      </div>
    </div>

    <!-- 线宽 -->
    <div class="fp-section">
      <div class="fp-label">线宽</div>
      <div class="fp-btns">
        <button
          v-for="w in [1, 1.5, 2, 3]"
          :key="w"
          class="fp-btn"
          :class="{ active: current.width === w }"
          @click="setWidth(w)"
        >
          {{ w }}
        </button>
      </div>
    </div>

    <!-- 连线专属：线型 & 箭头 -->
    <template v-if="hasEdge">
      <div class="fp-section">
        <div class="fp-label">线型</div>
        <div class="fp-btns">
          <button
            class="fp-btn"
            :class="{ active: !current.dashed }"
            @click="setDashed(false)"
          >
            实线
          </button>
          <button
            class="fp-btn"
            :class="{ active: current.dashed }"
            @click="setDashed(true)"
          >
            虚线
          </button>
        </div>
      </div>
      <div class="fp-section">
        <div class="fp-label">箭头</div>
        <div class="fp-btns">
          <button class="fp-btn" @click="setArrow('none')">无</button>
          <button class="fp-btn" @click="setArrow('single')">单向</button>
          <button class="fp-btn" @click="setArrow('double')">双向</button>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue'
import type { Cell, Edge, Node } from '@antv/x6'

const props = withDefaults(defineProps<{ cells?: Cell[] }>(), {
  cells: () => []
})

const version = ref(0)

const fillColors = [
  '#ffffff', '#e6fffb', '#eef3ff', '#fff7e6',
  '#f4edff', '#fef0f0', '#f5f6f7', '#1f2329'
]
const strokeColors = [
  '#4e5969', '#1f2329', '#3370ff', '#00c6a7',
  '#ff8f1f', '#8f5eff', '#f53f3f', '#00b42a'
]
const textColors = [
  '#1f2329', '#4e5969', '#86909c', '#ffffff',
  '#3370ff', '#00c6a7', '#ff8f1f', '#f53f3f'
]

const nodes = computed(() => props.cells.filter((c): c is Node => c.isNode()))
const edges = computed(() => props.cells.filter((c): c is Edge => c.isEdge()))
const hasNode = computed(() => nodes.value.length > 0)
const hasEdge = computed(() => edges.value.length > 0)

const title = computed(() => {
  if (hasNode.value && hasEdge.value) return `已选 ${props.cells.length} 项`
  if (hasNode.value) return nodes.value.length > 1 ? `节点 ×${nodes.value.length}` : '节点样式'
  return edges.value.length > 1 ? `连线 ×${edges.value.length}` : '连线样式'
})

// 从第一个匹配单元读取当前值（依赖 version 触发刷新）
const current = computed(() => {
  void version.value
  const node = nodes.value[0]
  const edge = edges.value[0]
  const ref0 = node || edge
  return {
    fill: node ? node.attr('body/fill') : null,
    stroke: ref0 ? ref0.attr(node ? 'body/stroke' : 'line/stroke') : null,
    textFill: node ? node.attr('text/fill') : null,
    width: ref0 ? ref0.attr(node ? 'body/strokeWidth' : 'line/strokeWidth') : null,
    dashed: edge ? !!edge.attr('line/strokeDasharray') : false
  }
})

function bump() {
  version.value++
}

function setFill(color: string) {
  nodes.value.forEach((n) => n.attr('body/fill', color))
  bump()
}
function setStroke(color: string) {
  nodes.value.forEach((n) => n.attr('body/stroke', color))
  edges.value.forEach((e) => e.attr('line/stroke', color))
  bump()
}
function setTextFill(color: string) {
  nodes.value.forEach((n) => n.attr('text/fill', color))
  bump()
}
function setWidth(w: number) {
  nodes.value.forEach((n) => n.attr('body/strokeWidth', w))
  edges.value.forEach((e) => e.attr('line/strokeWidth', w))
  bump()
}
function setDashed(dashed: boolean) {
  edges.value.forEach((e) => e.attr('line/strokeDasharray', dashed ? '6 4' : null))
  bump()
}
function setArrow(mode: 'none' | 'single' | 'double') {
  const block = { name: 'block', width: 10, height: 8 }
  edges.value.forEach((e) => {
    e.attr('line/sourceMarker', mode === 'double' ? block : null)
    e.attr('line/targetMarker', mode === 'none' ? null : block)
  })
  bump()
}
</script>

<style scoped>
.format-panel {
  position: absolute;
  top: 16px;
  right: 16px;
  width: 216px;
  background: #fff;
  border: 1px solid #e5e6eb;
  border-radius: 10px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.1);
  padding: 14px 16px;
  z-index: 20;
}

.fp-title {
  font-size: 13px;
  font-weight: 600;
  color: #1f2329;
  margin-bottom: 12px;
}

.fp-section {
  margin-bottom: 12px;
}

.fp-label {
  font-size: 12px;
  color: #86909c;
  margin-bottom: 6px;
}

.fp-swatches {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 4px;
}

.sw {
  width: 100%;
  aspect-ratio: 1;
  border: 1px solid #e5e6eb;
  border-radius: 4px;
  padding: 0;
  transition: transform 0.1s ease, box-shadow 0.1s ease;
}

.sw:hover {
  transform: scale(1.12);
}

.sw.active {
  box-shadow: 0 0 0 2px #3370ff;
}

.sw-none {
  position: relative;
  background: #fff;
  overflow: hidden;
}

.sw-none::after {
  content: '';
  position: absolute;
  left: 50%;
  top: -2px;
  width: 1px;
  height: 140%;
  background: #f53f3f;
  transform: rotate(45deg);
  transform-origin: center;
}

.fp-btns {
  display: flex;
  gap: 6px;
}

.fp-btn {
  flex: 1;
  height: 28px;
  border: 1px solid #e5e6eb;
  border-radius: 6px;
  background: #fff;
  font-size: 12px;
  color: #4e5969;
  transition: all 0.15s ease;
}

.fp-btn:hover {
  border-color: #3370ff;
  color: #3370ff;
}

.fp-btn.active {
  border-color: #3370ff;
  background: #eef3ff;
  color: #3370ff;
}
</style>
