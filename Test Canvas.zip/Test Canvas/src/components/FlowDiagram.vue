<template>
  <div class="flow-diagram">
    <FlowBoard
      v-if="mode === 'edit'"
      :data="modelValue"
      @change="onChange"
      @save="mode = 'preview'"
    />
    <FlowPreview v-else :data="modelValue" @edit="mode = 'edit'" />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import FlowBoard from './FlowBoard.vue'
import FlowPreview from './FlowPreview.vue'
import type { BoardMode, GraphData } from '../flow/types'

const props = withDefaults(
  defineProps<{
    /** v-model：初始化渲染数据；编辑时实时更新，可持久化后作为下次初值 */
    modelValue?: GraphData | null
    /** 初始模式，默认编辑态 */
    initialMode?: BoardMode
  }>(),
  {
    modelValue: null,
    initialMode: 'edit'
  }
)

const emit = defineEmits<{
  (e: 'update:modelValue', value: GraphData): void
}>()

const mode = ref<BoardMode>(props.initialMode)

function onChange(data: GraphData) {
  emit('update:modelValue', data)
}
</script>

<style scoped>
.flow-diagram {
  width: 100%;
  height: 100%;
}
</style>
