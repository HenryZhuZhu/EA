# 飞书流程画图板

基于 **AntV X6 + Vite + Vue3** 实现的类飞书流程图绘制工具。

## 功能

- 🎨 四类流程节点（开始/结束、处理、判断、数据 IO），左侧面板拖拽创建
- 🔗 悬停连接桩连线，自动折线路由（manhattan）
- 🖱️ 框选 / 多选、复制粘贴、撤销重做
- 🔍 缩放平移、对齐辅助线、缩略图小地图
- ✏️ 双击节点就地编辑文本
- 💾 localStorage 持久化 + 导出 JSON

## 快速开始

```bash
npm install
npm run dev
```

浏览器打开 http://localhost:5173

## 项目上下文

关键架构决策与约定见 [CONTEXT.md](./CONTEXT.md)，请在做重要改动时同步更新。
