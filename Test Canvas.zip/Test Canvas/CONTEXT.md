# 项目上下文管理（CONTEXT.md）

> 本文件用于沉淀「飞书流程画图板」项目的关键上下文，便于后续开发、协作与 AI 辅助时快速对齐。
> 每次做出重要架构决策、新增能力或修改约定时，请同步更新本文件。

---

## 1. 项目概述

- **名称**：feishu-flow-board（类飞书流程画图板）
- **目标**：基于 Web 的流程图绘制工具，交互风格对标飞书文档中的流程图组件。
- **技术栈**：Vite 5 + Vue 3（`<script setup lang="ts">` + TypeScript）+ AntV X6 2.x。
- **运行方式**：`npm install` → `npm run dev`（默认 http://localhost:5173）。
- **类型校验**：`npm run type-check`（vue-tsc）；`npm run build`（Vite/esbuild 转译）。
- **平台范围**：仅面向 **Web 桌面端**，不做移动端 / 触屏适配（无需响应式布局、touch 手势、小屏交互）。

## 2. 核心能力清单

| 能力 | 说明 | 实现位置 |
| --- | --- | --- |
| 节点拖拽创建 | 从左侧面板拖入四类节点 | `StencilPanel.vue` + `Dnd` 插件 |
| 自定义节点样式 | 开始/结束、处理、判断、数据 | `src/flow/shapes.js` |
| 连线 | 悬停显示连接桩、manhattan 路由、圆角折线 | `useGraph.js` connecting 配置 |
| 框选 / 多选 | 橡皮筋框选 | `Selection` 插件 |
| 撤销 / 重做 | 历史记录 | `History` 插件 |
| 复制 / 粘贴 | 剪贴板 | `Clipboard` 插件 |
| 缩放 / 平移 | Ctrl/⌘ + 滚轮缩放，右键/滚轮平移 | Graph `mousewheel` / `panning` |
| 对齐辅助线 | 拖拽吸附 | `Snapline` 插件 |
| 缩放尺寸调整 | 选中节点可拉伸 | `Transform` 插件 |
| 旋转 | 节点：顶部旋转手柄（Transform，15° 吸附） | `Transform` 插件 |
| 连线端点锚点 | 选中连线时两端出现圆形锚点，拖动可伸缩/旋转/重连（拖到节点连接桩则吸附） | source/target-arrowhead 边工具 / `FlowBoard.vue` addEdgeTools |
| 缩略图 | 右下角小地图 | `MiniMap` 插件 |
| 节点文本编辑 | 双击节点弹出输入框 | `FlowBoard.vue` `editNodeLabel` |
| 格式面板 | 选中图形后右上角浮层，改填充/边框/线条色、文字色、线宽、线型、箭头 | `FormatPanel.vue` |
| 右键菜单 | 节点/连线：复制/删除/置顶/置底；空白：粘贴/全选/适应/清空 | `ContextMenu.vue` + `FlowBoard.vue` |
| 数据持久化 | localStorage 保存 / 载入 | `useGraph.js` `saveGraph`/`loadGraph` |
| 导出 | 导出画布 JSON 文件 | `FlowBoard.vue` `exportJSON` |

## 3. 左侧图形面板（对标飞书）

面板分三大类，配置集中在 `src/flow/nodeTemplates.js`（`SHAPE_CATEGORIES`），图形注册在 `src/flow/shapes.js`：

| 分类 | 包含图形 | 类型 |
| --- | --- | --- |
| **基础** | 矩形、圆角矩形、椭圆、圆形、菱形、平行四边形、三角形、梯形、五/六/八边形、星形、十字、左/右/双向箭头、圆柱、标注、文本 | 节点（拖拽） |
| **直线** | 直线、箭头、双向箭头、折线、曲线 | 连线（拖到落点 / 点击插入中央） |
| **流程图** | 开始/结束、处理、判断、数据、文档、准备、连接点、数据库、显示、手动输入、手动操作、卡片、预定义流程、延迟、页外连接、存储数据、内部存储 | 节点（拖拽） |

约定：
- `kind: 'node'` 的项通过 `Dnd` 拖拽创建；`kind: 'edge'` 的项支持**拖到画布落点插入**（纯点击则插入到可视区中央）。
- **文本**工具：拖拽=放到落点；点击=进入文本插入光标模式（画布光标变 text），下一次空白点击落点创建文本并就地编辑（Esc 取消）。
- 面板项含 `icon`（SVG 字符串，viewBox 44x30），通过 `v-html` 渲染为预览小图标。
- 分类可折叠（`StencilPanel.vue` 的 `collapsed`）。
- 新增图形：先在 `shapes.js` 注册 shape，再到 `nodeTemplates.js` 对应分类下加一项。

## 4. 目录结构

```
Test Canvas/
├── index.html                 # 入口 HTML（引用 /src/main.ts）
├── vite.config.ts             # Vite 配置（vue 插件、@ 别名、端口）
├── tsconfig.json              # TS 配置（引用 @vue/tsconfig）
├── tsconfig.node.json         # 构建工具侧 TS 配置
├── package.json               # 依赖与脚本（dev / build / type-check）
├── CONTEXT.md                 # 本上下文管理文件
├── public/
│   └── favicon.svg
└── src/
    ├── main.ts                # 应用入口
    ├── env.d.ts               # Vue SFC / vite 类型声明
    ├── App.vue                # 根组件：持有 v-model 数据 + 持久化到“数据库”(localStorage 演示)
    ├── styles/global.css      # 全局样式
    ├── components/
    │   ├── FlowDiagram.vue    # 对外封装组件：v-model 绑定 + 编辑/预览模式切换
    │   ├── FlowBoard.vue      # 编辑模式编排：头部 + 左侧面板 + 右侧画布（:data + @change/@save）
    │   ├── FlowPreview.vue    # 保存后的只读缩略卡片（:data 渲染，对标飞书文档内嵌流程图）
    │   ├── FormatPanel.vue    # 选中图形后的格式浮层（颜色/线宽/线型/箭头）
    │   ├── ContextMenu.vue    # 右键菜单（纯展示，动作 emit('select')）
    │   └── board/
    │       ├── BoardHeader.vue   # 头部工具栏（动作 emit('action')）
    │       ├── BoardStencil.vue  # 左侧图形面板（三大类拖拽源 + 图片上传）
    │       └── BoardCanvas.vue   # 右侧主画布（持有 canvas/minimap DOM，@ready 上抛）
    ├── composables/
    │   ├── useFlowBoard.ts    # 主 hook：创建画布、装配交互、组合其余 hooks
    │   ├── useFlowActions.ts  # 工具栏/右键动作分发（onAction）
    │   ├── useContextMenu.ts  # 右键菜单状态与菜单项
    │   ├── useNodeEditing.ts  # 节点文本就地编辑 + 文本插入光标模式
    │   └── useImageUpload.ts  # 图片选择/读取/插入为图片节点
    └── flow/
        ├── shapes.ts          # 注册自定义节点/连线（含 basic-image 图片节点）
        ├── nodeTemplates.ts   # 左侧面板节点配置（SHAPE_CATEGORIES）
        ├── graph.ts           # 画布工厂 createGraph/createPreviewGraph + 持久化
        └── types.ts           # 共享类型（ShapeItem/MenuItem/FlowAction/BoardMode…）
```

## 5. 关键约定与设计决策

- **节点形状注册集中在 `shapes.js`**：新增节点类型时先在此注册，再到 `nodeTemplates.js` 加入面板项。
- **图实例单一归属**：`graph` 由 `FlowBoard.vue` 通过 `shallowRef` 持有，子组件通过 props 使用，避免多处创建。
- **工具栏解耦**：`Toolbar.vue` 不直接操作 graph，只 `emit('action', name)`，动作逻辑集中在 `FlowBoard.vue` 的 `onAction`。
- **持久化 key**：`localStorage` 键名为 `feishu-flow-board-data`（见 `STORAGE_KEY`）。
- **连接桩**：默认隐藏，鼠标进入节点时通过 DOM 显示（`bindPortVisibility`）。
- **右键已让位菜单**：画布平移改为 `mouseWheel`（滚轮平移，Ctrl/⌘+滚轮缩放），右键专用于上下文菜单。
- **格式面板取值**：按 `body/*`（节点）与 `line/*`（连线）attr 路径读写；文字色用 `text/fill`（内置形状标签可由 `text` 选择器命中）。
- **菜单/面板与 graph 解耦**：`ContextMenu` 只 `emit('select', action)`，`FormatPanel` 直接操作传入的 cells；菜单动作复用 `onAction`。

## 6. 快捷键

| 快捷键 | 功能 |
| --- | --- |
| ⌘/Ctrl + C / V | 复制 / 粘贴 |
| ⌘/Ctrl + Z | 撤销 |
| ⌘/Ctrl + Shift + Z / Ctrl + Y | 重做 |
| Delete / Backspace | 删除选中 |
| ⌘/Ctrl + A | 全选 |
| ⌘/Ctrl + 滚轮 | 缩放 |
| 右键拖拽 / 滚轮 | 平移画布 |

## 7. 待办 / 可扩展方向（TODO）

- [ ] 节点右键菜单（复制、置顶、删除等）
- [ ] 连线文本双击编辑
- [ ] 导入 JSON / 从后端加载
- [ ] 多主题（暗色模式）
- [ ] 协同编辑（结合 WebSocket / CRDT）
- [ ] 导出 PNG / SVG（`@antv/x6-plugin-export`）
- [ ] 节点分组 / 泳道

## 8. 变更记录（Changelog）

| 日期 | 变更 |
| --- | --- |
| 2026-07-06 | 初始化项目：完成画板、节点、工具栏、持久化与示例流程 |
| 2026-07-06 | 左侧面板重构为「基础/直线/流程图」三大类，新增基础图形、文档/准备节点及多种连线类型 |
| 2026-07-06 | 新增选中图形格式浮层（FormatPanel）与右键菜单（ContextMenu）；右键从平移改为专用菜单 |
| 2026-07-06 | 修复拖拽无法创建节点（误将画布设为 Dnd 排除区 dndContainer）；开启所有图形旋转 |
| 2026-07-06 | 新增独立连线旋转手柄；直线/箭头/双向/曲线显式指定 router:normal，保证对角线为直线而非 L 形 |
| 2026-07-06 | 连线交互改为端点锚点（source/target-arrowhead 边工具）替代旋转图标；connecting.allowBlank 改 true，validateConnection 允许端点落空白 |
| 2026-07-06 | 连线支持拖到画布任意位置插入；文本工具新增点击光标模式（点击落点创建并就地编辑） |
| 2026-07-06 | 参考飞书面板扩充基础（19）与流程图（17）图形库；shapes.js 新增 basicPolygon/basicPath/flowPolygon/flowPath 工厂函数 |
| 2026-07-06 | 全量迁移到 TypeScript；画板拆分为「头(BoardHeader)/左(BoardStencil)/右(BoardCanvas)」三组件 + composables hooks（useFlowBoard 等） |
| 2026-07-06 | 左侧「基础」新增图片上传（basic-image 节点，支持四角缩放/旋转/拖动/四向连线） |
| 2026-07-06 | 保存后切换到只读缩略预览（FlowPreview，对标飞书文档内嵌流程图），点击「编辑」回到画板 |
| 2026-07-06 | 新增 FlowDiagram 封装组件：内部切换编辑/预览，支持 `v-model` 双向绑定（初始化渲染 + 编辑实时上抛）；数据持久化交由宿主（App 用 localStorage 演示“数据库”），作为下次初始化数据 |
