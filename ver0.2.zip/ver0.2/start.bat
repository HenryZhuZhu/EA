@echo off
chcp 65001 >nul 2>nul
echo ========================================
echo   EA系统 打分积分版 原型 - 本地启动
echo ========================================
echo.

cd /d "%~dp0"

:: Try Python 3
where python >nul 2>nul
if %errorlevel%==0 (
    echo [OK] 检测到 Python，启动本地服务器...
    echo.
    echo   访问地址: http://localhost:8080
    echo   按 Ctrl+C 停止服务器
    echo.
    start http://localhost:8080
    python -m http.server 8080
    goto :end
)

:: Try Python 2
where python2 >nul 2>nul
if %errorlevel%==0 (
    echo [OK] 检测到 Python2，启动本地服务器...
    start http://localhost:8080
    python2 -m SimpleHTTPServer 8080
    goto :end
)

:: Try Node.js npx
where npx >nul 2>nul
if %errorlevel%==0 (
    echo [OK] 检测到 Node.js，启动本地服务器...
    start http://localhost:8080
    npx -y http-server -p 8080 -c-1
    goto :end
)

:: Fallback: just open the file directly
echo [!] 未检测到 Python 或 Node.js，尝试直接打开 HTML 文件...
echo     注意: 部分功能可能需要本地服务器才能正常工作
echo.
start index.html

:end
