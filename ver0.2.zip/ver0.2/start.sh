#!/bin/bash
echo "========================================"
echo "  EA系统 打分积分版 原型 - 本地启动"
echo "========================================"
echo ""

cd "$(dirname "$0")"

# Try Python 3
if command -v python3 &>/dev/null; then
    echo "[OK] 检测到 Python3，启动本地服务器..."
    echo ""
    echo "  访问地址: http://localhost:8080"
    echo "  按 Ctrl+C 停止服务器"
    echo ""
    open http://localhost:8080 2>/dev/null || xdg-open http://localhost:8080 2>/dev/null
    python3 -m http.server 8080
    exit 0
fi

# Try Python 2
if command -v python &>/dev/null; then
    echo "[OK] 检测到 Python，启动本地服务器..."
    open http://localhost:8080 2>/dev/null || xdg-open http://localhost:8080 2>/dev/null
    python -m SimpleHTTPServer 8080
    exit 0
fi

# Try Node.js
if command -v npx &>/dev/null; then
    echo "[OK] 检测到 Node.js，启动本地服务器..."
    open http://localhost:8080 2>/dev/null || xdg-open http://localhost:8080 2>/dev/null
    npx -y http-server -p 8080 -c-1
    exit 0
fi

# Fallback
echo "[!] 未检测到 Python 或 Node.js，尝试直接打开..."
open index.html 2>/dev/null || xdg-open index.html 2>/dev/null
